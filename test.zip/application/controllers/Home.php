<?php

    class Home extends CI_Controller {
        public function __construct() {
            parent::__construct();
            $this->load->model("test_model");
            //  die('sadsa');
        }

        function exercise2()
        {
          //For Edit the data  
          $id = $this->uri->segment(3);
          if($id != "")
          {
            $data['edit'] = $this->test_model->select_data_where_row('router','id',$id);
          } 
          $data['alldata'] = $this->test_model->select_data('router','status','active');
          $this->load->view('header');
          $this->load->view('test2',$data);
          $this->load->view('footer');
        }


        function exercise3()
        {
          //For Edit the data  
          $id = $this->uri->segment(3);
          if($id != "")
          {
            $data['edit'] = $this->test_model->select_data_where_row('router','id',$id);
          } 
          $data['alldata'] = $this->test_model->select_data('router','status','active');
          $this->load->view('header');
          $this->load->view('test3',$data);
          $this->load->view('footer');
        }
//========================AJAX start=============================================
        //Add data
        function index()
        {
          $this->load->view('header');
          $this->load->view('test');
          $this->load->view('footer');
        }
        
        function get_all_data()
        {
          $data = $this->test_model->select_data('router','status','active');
          echo json_encode($data);
        }

        function add()
        {
            $data = array('sapid' =>$this->input->post('sapid'),
            'hostname' =>$this->input->post('hostname'),
            'loopback' =>$this->input->post('loopback'),
            'macaddress' =>$this->input->post('macaddress'));
            $adata = $this->test_model->insert_data('router',$data);
            echo json_encode($adata);
        }

        //Update data
        function update()
        {
            $data = array('sapid' =>$this->input->post('sapid'),
            'hostname' =>$this->input->post('hostname'),
            'loopback' =>$this->input->post('loopback'),
            'macaddress' =>$this->input->post('macaddress'));
            $id = $this->input->post('id');
            $adata = $this->test_model->update_data('router',$data,'id',$id);
            echo json_encode($adata);
            // redirect('home');
        }

        //Soft Delete
        function delete()
        {   
            $id = $this->input->post('id');
            $data = array('status' =>"deleted");
            $adata = $this->test_model->update_data('router',$data,'id',$id);
            echo json_encode($adata);
        }

// ==================================AJAX END ==================================        
       
        function mvc_curd()
        {
          //For Edit the data  
          $id = $this->uri->segment(3);
          if($id != "")
          {
            $data['edit'] = $this->test_model->select_data_where_row('router','id',$id);
          } 
          $data['alldata'] = $this->test_model->select_data('router','status','active');
          $this->load->view('header');
          $this->load->view('test1',$data);
          $this->load->view('footer');
        }
        function add_mvc()
        {
            $data = array('sapid' =>$this->input->post('sapid'),
            'hostname' =>$this->input->post('hostname'),
            'loopback' =>$this->input->post('loopback'),
            'macaddress' =>$this->input->post('macaddress'));
            $adata = $this->test_model->insert_data('router',$data);
            redirect('home/mvc_curd');
        }

       function update_mvc()
        {
            $data = array('sapid' =>$this->input->post('sapid'),
            'hostname' =>$this->input->post('hostname'),
            'loopback' =>$this->input->post('loopback'),
            'macaddress' =>$this->input->post('macaddress'));
            $id = $this->input->post('id');
            $adata = $this->test_model->update_data('router',$data,'id',$id);
            redirect('home/mvc_curd');
        }

        function delete_mvc()
        {   
            $id = $this->uri->segment(3);
            $data = array('status' =>"deleted");
            $adata = $this->test_model->update_data('router',$data,'id',$id);
            redirect('home/mvc_curd');
        }

        function genrate_dummy_data()
        {
            for ($i = 0; $i < 50; $i++) {
            $data = array('sapid' =>'sapid'.$i,
            'hostname' =>'hostname'.$i,
            'loopback' =>'loopback'.$i,
            'macaddress' =>'macaddress'.$i);
            $this->test_model->insert_data('router',$data); 
            }
        }

/////////////////////////////API Start////////////////////////////////////////////

// NOte : post_curl is curl functin writen helper

        function add_data()
        { 
            $getdata = array(
            'hostname' =>$this->input->post('hostname'),
            'loopback' =>$this->input->post('loopback'),
            'sapid' =>$this->input->post('sapid'),
            'macaddress' =>$this->input->post('macaddress'));
            $result = $this->test_model->insert_data('router',$getdata);
            
            $data['status'] = 0;
            $data['message'] = "Data Not inserted!";
            if($result)
            {
                $data['status'] = 0;
                $data['message'] = 'Data inserted!';
            }
            echo json_encode($data);
        }

        function update_data()
        {
           $getdata = array(
            'hostname' =>$this->input->post('hostname'),
            'loopback' =>$this->input->post('loopback'),
            'sapid' =>$this->input->post('sapid'),
            'macaddress' =>$this->input->post('macaddress'));
            $id = $this->input->post('id');
            $result = $this->test_model->update_data('router',$getdata,'id',$id);
            $data['status'] = 0;
            $data['message'] = "Data Not updated!";
            if($result)
            {
                $data['status'] = 0;
                $data['message'] = "Data updated!";
            }
            echo json_encode($data);
        }

        function get_data()
        {
            $sapid = $this->input->post('sapid');
            $result = $this->test_model->select_data_where_row('router','sapid',$sapid);
            $data['status'] = 0;
            $data['message'] = "Data Not found!";
            if($result)
            {
                $data['status'] = 0;
                $data['message'] = $result;
            }
            echo json_encode($data);
        }

        function get_iprange_data()
        {
            $id = $this->input->post('id');
            $result = $this->test_model->select_data_where_result('router','id',$id);
            $data['status'] = 0;
            $data['message'] = "Data Not found!";
            if($result)
            {
                $data['status'] = 0;
                $data['message'] = $result;
            }
            echo json_encode($data);
        }

        

        function delete_data()
        {
            $id = $this->input->post('id');
            $result = $this->test_model->delete_data('router','id',$id);
            $data['status'] = 0;
            $data['message'] = "Data not deleted!";
            if($result)
            {
                $data['status'] = 0;
                $data['message'] = "Data deleted!";
            }
            echo json_encode($data);
        }


    }