<?php

function post_curl($url,$post_data=FALSE) {
   $cSession1 = curl_init();
   curl_setopt($cSession1,CURLOPT_URL,$url);
   curl_setopt($cSession1, CURLOPT_CUSTOMREQUEST, "POST");
   curl_setopt($cSession1,CURLOPT_RETURNTRANSFER,true);
   curl_setopt($cSession1, CURLOPT_POSTFIELDS, $post_data);
   $result=curl_exec($cSession1);
   curl_close($cSession1);
   // echo "<pre>";
   // print_r($result);
   // die;
   return $result;
}

function get_curl($url){
  //  Initiate curl
  $ch = curl_init();
  // Disable SSL verification
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  // Will return the response, if false it print the response
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  // Set the url
  curl_setopt($ch, CURLOPT_URL,$url);
  // Execute
  $result=curl_exec($ch);
  return $result;
  // Closing
  // curl_close($ch);

  // // Will dump a beauty json :3
  // var_dump(json_decode($result, true));
}
