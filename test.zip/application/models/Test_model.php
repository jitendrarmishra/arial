
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Test_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }


    function insert_data($tablename, $data) {
        $this->db->insert($tablename, $data);
        return $this->db->insert_id();
    }

    function select_data($tablename, $columnName=false, $value=false,$limit=false) {
        $this->db->where($columnName, $value);
        if($limit)
        {
             $this->db->limit($limit);
        }
       
        $query = $this->db->get($tablename);
        //                                     echo $this->db->last_query();
        // die;
        return $query->result();
    }


    function select_data_where_row($tablename, $columnName1, $value1) {
        $this->db->where($columnName1, $value1);
             
        $query = $this->db->get($tablename);
        //                                  echo $this->db->last_query();
        // die;
        return $query->row();
    }


    function select_data_where_result($tablename, $columnName1, $value1,$columnName2=false, $value2=false) {
        $this->db->like($columnName1, $value1);
        if($columnName2)
        {
         $this->db->where($columnName2, $value2);
        }
        $query = $this->db->get($tablename);
       //                                  echo $this->db->last_query();
       // die;
        return $query->result();
    }


    function update_data($tablename, $data, $columnName, $value) {
        $this->db->where($columnName, $value);
        $this->db->update($tablename, $data);
        $updated_status = $this->db->affected_rows();
        if($updated_status):
            return $value;
        else:
            return false;
        endif;
                                echo $this->db->last_query();
       die;
    }

    function delete_data($tablename, $columnName, $id) {
        $this->db->where($columnName, $id);
        $this->db->delete($tablename);
         return $this->db->affected_rows();
    }

    

}

?>