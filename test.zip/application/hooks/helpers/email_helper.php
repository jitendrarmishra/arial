<?php

    function sms($mobileNumber,$message)
    {
          $authKey = "178491Afd8c7bhT59db20d0";
          $senderId = "ATCOOK";
          $route = "4";
          $postData = array(
          'authkey' => $authKey,
          'mobiles' => $mobileNumber,
          'message' => $message,
          'sender' => $senderId,
          'route' => $route,
          'unicode' => 1
          );

          $url="https://smsp.myoperator.co/api/sendhttp.php";
          $ch = curl_init();
          curl_setopt_array($ch, array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_POST => true,
          CURLOPT_POSTFIELDS => $postData
          ));
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
          $output = curl_exec($ch); 
          curl_close($ch);
    }


    function email($email_array) 
    {
      $url = 'https://api.sendgrid.com/';
      $user = 'aneesh@authenticook.com';
      $pass = 'Toggle_123';

      $json_string = array(
      'to' => array($email_array['emailto']),
      // 'cc' => array($email_array['cc']),
      'category' => $email_array['category']
      );

      $params = array(
        'api_user'  => $user,
        'api_key'   => $pass,
        'x-smtpapi' => json_encode($json_string),
        'to'        => $email_array['emailto'],
        // 'cc'        => $email_array['cc'],
        'subject'   => $email_array['subject'],
        'html'      => $email_array['html'],
        'fromname'  => $email_array['fromname'],
        'from'      => $email_array['from'],
      );


       $request =  $url.'api/mail.send.json';

      // Generate curl request
      $session = curl_init($request);
      // Tell curl to use HTTP POST
      curl_setopt ($session, CURLOPT_POST, true);
      // Tell curl that this is the body of the POST
      curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
      // Tell curl not to return headers, but do return the response
      curl_setopt($session, CURLOPT_HEADER, false);
      // Tell PHP not to use SSLv3 (instead opting for TLS)
      curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
      curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
      // obtain response
      $response = curl_exec($session);
      curl_close($session);
      // print everything out
      // print_r($response); 
      // print_r(json_encode($response));
  }

//1.EMAIL CONTENT (EACH EMAIL WHICH GOES TO Guest AND HOST WILL HAVE CORRESPONDING EMAIL COMING TO US):

  function newbookingmailforhost($mealname, $cuisinename, $totaldiners, $newdate, $username, $confirmationvouchercode, $city, $hostfname, $host_lname, $vegdiners, $nonvegdiners, $hostemail, $typeofmeal) {
    $baseurl = "https://www.authenticook.com/";
      
    if($totaldiners == 1) {
        $seattext = "seat";
    } else {
        $seattext = "seats";
    }
    
    $subject = "Meal Booking for ".$totaldiners." ".$seattext." for ".$cuisinename." - ".$mealname." on ".//date_format($newdate, "l dS F");
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
            <p style="margin:10px 0px;">Hey there,</p>
            <p style="margin:10px 0px;">We have received a meal booking with the below mentioned details</p>
            <p style="margin:10px 0px;"><b>Name of the booking guest: </b>'.$username.'</p>
            <p style="margin:10px 0px;"><b>Name of experience: </b>'.$username.'</p>
            <p style="margin:10px 0px;"><b>Confirmation Code: </b>'.$confirmationvouchercode.'</p>
            <p style="margin:10px 0px;"><b>Date: </b>'.date_format($newdate, "F dS, Y").'</p>
            <p style="margin:10px 0px;"><b>Time: </b>'.date_format($newdate, "F dS, Y").'</p>


            <p style="margin:10px 0px;"><b>Experience Type: </b>'.$typeofmeal.'</p>
            <p style="margin:10px 0px;"><b>Experience Sub Type: </b>'.$typeofmeal.'</p>
            <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>
         
            <p style="margin:10px 0px;"><b>No. of seats booked: </b>'.$totaldiners.'</p>';
            if($vegdiners != 0) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$vegdiners.'</p>';
            } if($nonvegdiners != 0) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Non Veg Seats: </b>'.$nonvegdiners.'</p>';
            }
            $message .= '
            <p style="margin:10px 0px;">You will receive a revised mail with the Guest details 36 hours before the experience. In the meantime, you can check the booking details on your profile dashboard (<a href="'.$baseurl.'host-upcoming-meals/" style="color: #FF5A5A; text-decoration: none;">click here to view</a>)</p>
            <p style="margin:10px 0px;">For any queries please give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you have any queries, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';
echo $message;
// $category = 'gen';
// $emailto = 'jitu.culdude@gmail.com';

// $email_array = array('emailto'=>$emailto,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'aneesh@authenticook.com','fromname'=>'Authenticook');
// $this.email($email_array);
}

//2. Email which goes to the booking user on completion of booking

function newbookingmailfordiner($mealname=false, $cuisinename=false, $username=false, $hostfname=false, $newdate=false, $email=false, $path=false) {
    $baseurl = "https://www.authenticook.com/";
    
    $subject = "Your Meal Confirmation Voucher for ".$cuisinename." - ".$mealname." on ".date_format($newdate, "F dS, Y");
    $message= '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>

        <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
            <p style="margin:10px 0px;">Hey '.$username.',</p>
            <p style="margin:10px 0px;">Thank you for booking the \''.$cuisinename.' - '.$mealname.'\' with host '.$hostfname.' on '.date_format($newdate, "F dS, Y").' at <time>. </p>
            <p style="margin:10px 0px;">We have attached the confirmation voucher in this mail. Please go through it for all the details.</p>
            <p style="margin:10px 0px;">Do share with us the details of the other guests accompanying you. This will help us create an experience that is more enriching for you and the other guests.</p>

  
            <p style="margin:0px;">You can share this information through your profile page (upcoming experiences) or write to us at  <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>


        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';
echo $message;
//  $category = 'gen';
// $emailto = $email;

// $email_array = array('emailto'=>$emailto,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
// $this.email($email_array);
}



// 3. Email which goes to the admin on booking

function newbookingmailforadmin($currency=false, $conversion_rate=false, $usertype=false, $userid=false, $mealname=false, $cuisinename=false, $newdate=false, $username=false, $hostfname=false, $hostlname=false, $hostid=false, $bookingid=false, $city=false, $hostlistingaddress=false, $typeofmeal=false, $vegnonvegtext=false, $experiencetypepvttext=false, $experiencetypectetext=false, $confirmationvouchercode=false, $totaldiners=false, $vegdiners=false, $nonvegdiners=false, $urlslug=false, $mealid=false, $meallistingid=false, $promocode=false, $experiencetype=false, $vegprice=false, $nonvegprice=false, $servicefeeveg=false, $servicefeenonveg=false, $discountpercent=false, $discountamount=false, $total_amount=false, $path=false, $additionalamount=false, $mealmindiners=false, $typeofdiner=false, $authenticoins_used=false) {
    
    $baseurl = "https://www.authenticook.com/";
        
    if($totaldiners == 1) {
        $seattext = "seat";
    } else {
        $seattext = "seats";
    }
    
    if($usertype == 1) {
        $formurl = $baseurl."authenticook-panel/editdiner.php?id=".$userid;
    } else if($usertype == 2) {
        $formurl = $baseurl."authenticook-panel/edithost.php?id=".$userid;
    } else if($usertype == 3) {
        $formurl = $baseurl."authenticook-panel/editpartnerchannel.php?id=".$userid;
    } 
    
    $subject = "Meal Booking for ".$totaldiners." ".$seattext." for ".$cuisinename." -  ".$mealname." on ".date_format($newdate, "dS F, Y");
    $message .= '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <img src="'.$baseurl.'email-images/logo.png">
        </div>
        <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
            <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
            <p style="margin:10px 0px;">We have received a booking with the below mentioned details</p>

            <p style="margin:10px 0px;"><b>Name of the booking guest: </b><a href="'.$formurl.'" style="color: #FF5A5A; text-decoration: none;">'.$username.'</a></p>

            <p style="margin:10px 0px;"><b>Date: </b>'.date_format($newdate, "F dS Y").'</p>
            <p style="margin:10px 0px;"><b>Time: </b>'.date_format($newdate, "F dS Y").'</p>

      <p style="margin:10px 0px;"><b>Name of experience: </b><a href="'.$baseurl.'meal/'.$urlslug.'/'.$mealid.'/'.$meallistingid.'/" style="color: #FF5A5A; text-decoration: none;">'.$mealid.' - '.$mealname.'</a></p>

        <p style="margin:10px 0px;"><b>Experience Unique Number: </b>'.$bookingid.'</p>
    <p style="margin:10px 0px;"><b>Experience Type: </b>'.$experiencetype.'</p>

   <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>
    <p style="margin:10px 0px;"><b>Host: </b><a href="'.$baseurl.'host/'.$hostfname.'/'.$hostid.'/" style="color: #FF5A5A; text-decoration: none;">'.$hostfname.' '.$hostlname.'</a></p>

    <p style="margin:10px 0px;"><b>Action: </b>Booking of a meal</p>
    <p style="margin:10px 0px;"><b>Private Dining Request: </b>'.$experiencetypepvttext.'</p>
     <p style="margin:10px 0px;"><b>Eligibility: </b>Loyalty /Group Discount / Wallet / Promo Code</p>
      <p style="margin:10px 0px;"><b>Confirmation Code: </b>'.$confirmationvouchercode.'</p>';
          
             $message .='
            <p style="margin:10px 0px;"><b>No. of seats booked: </b>'.$totaldiners.'</p>';
            if($vegnonvegtext == "Both") {
                $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$vegdiners.'</p>
                <p style="margin:10px 0px;"><b>Number of Non Veg Seats: </b>'.$nonvegdiners.'</p>';
            } else if($vegnonvegtext == "Veg") {
                $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$vegdiners.'</p>';
            } else if($vegnonvegtext == "Non-Veg") {
                $message .= '<p style="margin:10px 0px;"><b>Number of Non Veg Seats: </b>'.$nonvegdiners.'</p>';
            }



            // if(($experiencetypepvttext || $experiencetypectetext) == "Yes") {
            //     if($totaldiners < $mealmindiners) {
            //         if($additionalamount > 0) {
            //             $message .='<p style="margin:10px 0px;"><b>Additional Amount: </b>'.$currency.' '.number_format(ceil($additionalamount/$conversion_rate)).'</p>';
            //         }
            //     }
            // }

        
          
            if($vegdiners != 0) {
            $message .='<p style="margin:10px 0px;"><b>Veg Diner Fee '.$currency.': </b>'.$vegdiners.' x '.number_format(ceil($vegprice/$conversion_rate)).'</p>
            <p style="margin:10px 0px;"><b>Veg Service Fee '.$currency.': </b>'.$vegdiners.' x '.number_format(ceil($servicefeeveg/$conversion_rate)).'</p>';


            } if($nonvegdiners != 0) {
            $message .='<p style="margin:10px 0px;"><b>Non-Veg Diner Fee '.$currency.': </b>'.$nonvegdiners.' x '.number_format(ceil($nonvegprice/$conversion_rate)).'</p>
            <p style="margin:10px 0px;"><b>Non-Veg Service Fee '.$currency.': </b>'.$nonvegdiners.' x '.number_format(ceil($servicefeenonveg/$conversion_rate)).'</p>';
            }

            $message .= '
          <p style="margin:10px 0px;"><b>Promo Code: </b>'.$promocode.'</p>
            <p style="margin:10px 0px;"><b>Discount: </b>'.$discountpercent.'%</p>
            <p style="margin:10px 0px;"><b>Discount Amount '.$currency.': </b>'.number_format(ceil($discountamount/$conversion_rate)).'</p>
            <p style="margin:10px 0px;"><b>Authenticoins Used '.$currency.': </b>'.number_format(ceil($authenticoins_used/$conversion_rate)).'</p>
            <p style="margin:10px 0px;"><b>Total Amount '.$currency.': </b>'.number_format(ceil($total_amount/$conversion_rate)).'</p>


            <p style="margin:10px 0px;">The following actions are needed from your side</p>
            <ul>
                <li>You need to reach out to the Host '.$hostfname.' to inform her about this meal</li>
                <li>Also need to check if payment has come in</li>
                <li>Need to check if this meal is listed with any other agency / portal and change the inventory accordingly</li>
            </ul>
            <p style="margin:10px 0px;">Thank You,</p>
            <p style="margin:10px 0px;">Jarvis</p>
            <p>Team Authenticook</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
        </div>
    </body>
</html>';
    
    echo $message;
    die;
    // $email_array = array('emailto'=>$emailto,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
// $this.email($email_array);
}

// 5. Email which goes to a user who has just registered (this needs to be there for the guest checkout as well)
function newregistrationtodiner($email=false, $name=false) {
    $baseurl = "https://www.authenticook.com/";
    $subject = "Hey {$name} Get started on Authenticook";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
         <p style="margin:10px 0px;">Hey '.$name.',</p>
        <h3>Welcome to the Authenticook community!</h3>
          
            <p style="margin:10px 0px;">Get ready for experiences which will leave you spellbound. Be it a cooking class, or a food tour or other interesting activities, you will find them here, curated by our amazing hosts.</p>

            <p style="margin:10px 0px;">Before starting your journey, it would be nice if the community could get to know you better.</p>

            <p style="margin:10px 0px;">Complete your profile </p>


             <p>Completing your profile helps build trust in the Authenticook community. (<a href="'.$baseurl.'profile/" style="color: #FF5A5A; text-decoration: none;">Click here</a>)</p>
      <p style="margin:10px 0px;">Check out some of the amazing upcoming experiences!</p>

      <p style="margin:10px 0px;"><4 experiences which are auto updated - one each from meals, activities and events. Incase events are not listed, it could be populated with meal experience of a superhost and be shown here in the form of 2X2 tiles></p>

      <p style="margin:10px 0px;">Want to Invite your friends and family to Authenticook? Get 250 Authenticoins once they complete the experience.</p>


          <p style="padding:15px;width:150px!important;background-color: #F0413C!important;font-style: normal!important;cursor: pointer;border: 1px solid #F0413C!important;font-family: geogtq_medium;color:#FFF"><a href="'.$baseurl.'profile/" style="color: #FFF; text-decoration: none;">Invite your friends</a></p>


            <p style="margin:10px 0px;">Should you have any questions or comments, give us a shout at  <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
            <p style="margin:10px 0px;">We look forward to hosting you soon!</p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';
   $category = 'testing';
      $email_array = array('emailto'=>$email,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
email($email_array);
}


// 6. Email which goes to the admin on Guest Registration

function newregistrationdineradmin($name=false, $lname=false, $isd=false, $phone=false, $email=false, $city=false, $gender=false, $birthdate=false, $userid=false, $mode=false, $preference=false) {
    $baseurl = "https://www.authenticook.com/";
    
    $subject = "Guest Registration - New Guest on Authenticook";
    $message = "";
    $message .= '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <img src="'.$baseurl.'email-images/logo.png">
        </div>
        <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
            <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
            <p style="margin:10px 0px;">A new guest  just registered on Authenticook. The details are as follows.</p>

                      <p style="margin:10px 0px;"><b>Name: </b>'.$name.' '.$lname.'</p>
            <p style="margin:10px 0px;"><b>Phone Number: </b>'.$isd.' -'.$phone.'</p>
             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
            <p style="margin:10px 0px;"><b>Email: </b><a style="color: #FF5A5A; text-decoration: none;">'.$email.'</a></p>

           <p style="margin:10px 0px;"><b>Registration Mode: </b>'.$mode.'</p>
             <p style="margin:10px 0px;"><b>DOB: </b>'.$birthdate.'</p>
            <p style="margin:10px 0px;"><b>Gender: </b>'.$gender.'</p>

          <p style="margin:10px 0px;"><b>Food Preference: </b>'.$preference.'</p>
              <p style="margin:10px 0px;">Click <a href="'.$baseurl.'authenticook-panel/editdiner.php?id='.$userid.'" style="color: #FF5A5A; text-decoration: none;">here</a> to view the profile at the backend</p>';

   
             $message .= '<p style="margin:10px 0px;">Thank You,</p>
            <p style="margin:10px 0px;">Jarvis</p>
            <p>Team Authenticook</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
        </div>
    </body>
</html>';
 $category = 'testing';
      $email_array = array('emailto'=>$email,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
email($email_array);

}



//7. Email which goes to a user who has just signed up to newsletter
function newsletterwelcomeemail($email=false) {
    $baseurl = "https://www.authenticook.com/";
      
    $subject = "You have subscribed to the best Newsletter in town";
        $message = '<html>
        <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
        <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
        <p style="margin:10px 0px;">Hey there,</p>
        <p style="margin:10px 0px;">We have received your request for newsletter subscription. That\'s a great move!
        Be ready to receive updates from us on the upcoming food experiences!</p>


        <p style="margin:10px 0px;">Jump in and check out these amazing upcoming experiences!</p>

        <p style="margin:10px 0px;">Place here image<4 experiences which are auto updated - one each from meals, activities and events. Incase events are not listed, it could be populated with meal experience of a superhost and be shown here in the form of 2X2 tiles></p>

        <p style="margin:10px 0px;">Want to Invite your friends and family to Authenticook? Get 250 Authenticoins once they complete the experience. You will need to register as a Guest on the website. </p>


        <p style="padding:15px;width:150px!important;background-color: #F0413C!important;font-style: normal!important;cursor: pointer;border: 1px solid #F0413C!important;font-family: geogtq_medium;color:#FFF"><a href="'.$baseurl.'profile/" style="color: #FFF; text-decoration: none;">Invite your friends</a></p>




        <p style="margin:0px;">For any queries, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
        <p>Team Authenticook</p>
        <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
        <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
        <p style="margin-bottom: 0px;margin-top: 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
        </body>
        </html>';

      $category = 'testing';
      $email_array = array('emailto'=>$email,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
      email($email_array);
}

//11 Contact us email to the person asking the query
function sayhellotouser($contact_email=false, $fname=false) {
      $baseurl = "https://www.authenticook.com/";
      $subject = "Thanks for reaching out to us at Authenticook";
      $message = '<html>
      <body style="margin:0;padding:0;width:100%;margin:auto;">
      <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
      <img src="'.$baseurl.'email-images/logo.png">
      </div>
      <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
      <p style="margin-top:0px;">Hey '.$fname.',</p>

      <p style="margin:0px;line-height:25px;">Thanks for leaving your comments on our website. Our team will get back to you immediately on this. </p>

      <p style="margin:0px;">In the meantime, if you have any other queries, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #222; text-decoration: none;">contact@authenticook.com</a></p>


      <p>Team Authenticook</p>
      <p>Eat. Enjoy. Experience.</p>
      </div>
      <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
      <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
      <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
      </div>
      </body>
      </html>';

$category = 'Test';
$email_array = array('cc'=>'jitendra@togglehead.in','emailto'=>'siddhant@togglehead.in','category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
email($email_array);
}


// 12. Contact us email to the Admin

function sayhellotoadmin($contact_fname=false, $contact_lname=false, $contact_email=false, $contact_phone=false, $sayhellomsg=false) {
          $baseurl = "https://www.authenticook.com/";


          $subject = "Contact Us - Somebody just tried to contact you";
          $message = '<html>
          <body style="margin:0;padding:0;width:100%;margin:auto;">
          <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
          <img src="'.$baseurl.'email-images/logo.png">
          </div>
          <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
          <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
          <p style="margin:10px 0px;">Somebody has left a message for you</p>
          <p style="margin:10px 0px;"><b>Name: </b>'.$contact_fname.' '.$contact_lname.'</p>
          <p style="margin:10px 0px;"><b>Email: </b><span style="color: #FF5A5A; text-decoration: none;">'.$contact_email.'</span></p>
          <p style="margin:10px 0px;"><b>Phone Number: </b>'.$contact_phone.'</p>
          <p style="margin:10px 0px;"><b>Message: </b>'.$sayhellomsg.'</p>
          <p style="margin:10px 0px;">Thank You,</p>
          <p style="margin:10px 0px;">Jarvis</p>
          <p>Team Authenticook</p>
          </div>
          <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
          <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
          </div>
          </body>
          </html>';

  $category = 'Test';
$email_array = array('cc'=>'jitendra@togglehead.in','emailto'=>'siddhant@togglehead.in','category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
email($email_array);
}



// 13. Forgot Password


function forgotpassword($email=false, $randomnumber=false) {
    $baseurl = "https://www.authenticook.com/";
   
    
    $subject = "Reset your Authenticook Password";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
            <p style="margin-top:0px;">Hey there,</p>
            <p style="margin:10px 0px;">We have received a request to reset the password for your account. Click the button below and reset your password.</p>
            <p style="margin:10px 0px;">Don\'t you worry, it happens to everyone.</p>
            <p style="padding: 10px 0px;"><a style="padding: 10px 15px; background-color: #FF5A5A; color: #fff; text-decoration: none;" href="'.$baseurl.'reset-password/'.$randomnumber.'/">Reset your password</a></p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';
     $category = 'Test';
$email_array = array('emailto'=>$email,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com');
email($email_array);
}


// 20 Email which goes to the sender of the invite (thank you)

function invitefriendssender($email=false, $username=false,$user_unique_code=false) {
    $baseurl = "https://www.authenticook.com/";
    $subject = "Thank you for inviting your friends and family!";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
            <p style="margin:10px 0px;">Hey '.$username.',</p>
            <p style="margin:10px 0px;">Thank you for inviting your friends and family to Authenticook.</p>
            <p style="margin:10px 0px;">We appreciate your gesture and believe that this is the best way to build our community of passionate home-chefs and fabulous guests.</p>


            <p style="margin:10px 0px;">Want to Invite more friends and family to Authenticook?</p>

             <p style="padding:15px;width:150px!important;background-color: #F0413C!important;font-style: normal!important;cursor: pointer;border: 1px solid #F0413C!important;font-family: geogtq_medium;color:#FFF"><a href="'.$user_unique_code.'/" style="color: #FFF; text-decoration: none;">Invite your friends</a></p>


            <p style="margin:0px;">If you have any questions or comments, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';

   $category = 'testing';
      $email_array = array('emailto'=>$email,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
email($email_array);
}
 

function invitefriendsreceiver($email, $userrow, $baseurl) 
{
   
    $email = 'jitendra@togglehead.in';
    $subject = "Lucky You! An Authenticook Invite!";
    $url = "http://localhost:3000/authenticook/";

    $baseurl = "https://www.authenticook.com/";

    $userprofilepic = $userrow->user_profile_pic;
    $userviafb = $userrow->via_facebook;
    $userviagmail = $userrow->via_gmail;

    $pic = $baseurl."images/hosts/profile-pictures/blank.png";

    if(!empty($userviafb)) 
    {
        $pic = "https://graph.facebook.com/".$userviafb."/picture?type=large&width=130&height=130";
    }
    else if(!empty($userviagmail)) 
    {
        $pic = $userprofilepic;
    }
    else
    {
        if(empty($userprofilepic))
        {
            $pic = $baseurl."images/hosts/profile-pictures/blank.png";
        }
        else
        {
            $pic = $baseurl."images/hosts/profile-pictures/".$userprofilepic;
        }
    }

    $year = date('Y', strtotime($userrow->registered_date_time));

    $body = '<html>
        <head>
            <title>Emailer</title>
            <link href="https://fonts.googleapis.com/css?family=Open Sans" rel="stylesheet">
        </head>
        <body style="font-family: \'Open Sans\';">
            <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
                <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
            </div>
            <table style="width:100%;border:2px solid #FF5A5A;border-top:0;padding:25px;margin:auto;">
                <!--tr>
                    <td><a href="https://www.authenticook.com/" target="_blank"><img src="https://www.authenticook.com/images/logo.png" style="margin-bottom:15px;"></a></td>
                </tr-->
                <tr>
                    <td>
                        <p style="font-size:20px;font-weight:300;">'.ucfirst($userrow->user_fname).' sent you &#8377;350 for your first meal experience!</p>
                        <p style="font-size:12px;">On Authenticook, you can book meal experiences, cooking classes and other interesting activities in your own city or a new place you are traveling to. There is no better way to experience culinary diversity than by dining with a local at their home in the company of like-minded, fun people. Just log in to our website www.authenticook.com to check out all our experiences and places we are present in. Sign up to get &#8377;350 off your first meal experience.</p>
                        <p style="font-size:14px;"><a href="'.$url.'refer/'.$userrow->user_unique_code.'" target="_blank"><span style="display:inline-block;background-color:#FF5A5A;color:#fff;width:150px;text-align:center;padding:10px 0;">Accept Invitation</span></a></p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="width:70px;display:inline-block;vertical-align:middle;"><img src="'.$pic.'" style="width:100%;"></p><p style="display:inline-block;vertical-align:middle;padding-left:20px;font-size:14px">'.ucwords($userrow->user_fname.' '.$userrow->user_lname).'<br>'.ucwords($userrow->user_city).'<br>On Authenticook since '.$year.'</p>
                    </td>
                </tr>
                <!--tr>
                    <td>
                        <p style="font-size:14px;">Authenticook<br>Bombay Connect,<br>501 A Pinnacle Corporate Park,<br>Bandra Kurla Complex,<br>MMRDA Area, Near Trade Centre,<br>Mumbai 400051</p>
                        <p style="font-size:14px;"><a href="https://www.authenticook.com/" target="_blank"><span style="display:inline-block;color:#FF5A5A;">Earn Authenticoins</span></p>
                        <p style="font-size:14px;"><a href="https://www.authenticook.com/" target="_blank"><span style="display:inline-block;color:#FF5A5A;">Unsubscribe</span></a></p>
                    </td>
                </tr-->
            </table>
            <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
                <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            </div>
        </body>
    </html>';
   $category = 'testing';
      $email_array = array('emailto'=>$email,'category'=>$category,'subject'=>$subject,'html'=>$body,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
      email($email_array);
}


////////////////////////////////////////////////


function newregistrationtohost($email, $name) {
    $baseurl = "https://www.authenticook.com/";
    
    $subject = "Welcome to Authenticook";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
        <h3>Welcome to the Authenticook community!</h3>
            <p style="margin:10px 0px;">Hello '.$name.',</p>
            <p style="margin:10px 0px;">Greetings from everyone at Authenticook.</p>
            <p style="margin:10px 0px;">We are looking for talented home-chefs like you whose passion is cooking and hosting.</p>
            <p style="margin:10px 0px;">As a next step, someone from our team will get in touch with you to take the registration process forward and on-board you as an Authenticook Host.</p>

            <p style="margin:0px;">Should you have any questions or comments, please reach us out atan(arg) <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
            <p style="margin:10px 0px;">We look forward to getting you on board soon!</p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';
        $category = 'Test';
$email_array = array('emailto'=>$email,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
email($email_array);
}


// 34 Email to guest for promo code once they have completed booking 10 seats
// 35 Email to guest for promo code once they have completed booking 50 seats

/* Anil */
function sendloyalty($email=false, $code=false, $type=0, $level=false) {
    $baseurl = "https://www.authenticook.com/";
    $year = date('Y', strtotime($userrow['registered_date_time']));

    if($type == 1)
    {
        $no = 10;
        $per = 15;
        $text = '';
        $subject = "Congratulations! You have unlocked the small joys of life!";
        $text = "You have successfully completed booking 10 seats and unlocked the small joys of life that Authenticook has to offer";
    }
    else
    {
        $no = 50;
        $per = 50;
        $text = '';
        $subject = "Congratulations! You have unlocked the small joys of life!";
        $text = "You have successfully completed booking booking 50 seats and unlocked the small joys of life that Authenticook has to offer";
    }

     $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
           <p style="font-size:20px;font-weight:300;">Congratulations!</p>
                     
                        <p>'.$text.'</p>
                        <p>Here is your '.$per.'% discount code to use on your next meal: '.$code.'</p>

                        <p>To avail the discount, simply enter the code when booking your next meal on Authenticook</p>
 <p style="margin:0px;">Please feel free to write to us at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a> for any queries.</p>






            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';




    echo $message;
}



// Guest gets email saying their request has been submitted and is awaiting host acceptance
function requestadatemailtodiner($cuisinename=false, $request_meal_name=false, $fname=false, $name=false, $city=false, $hostname=false, $dateselected1=false, $dateselected2=false, $dateselected3=false, $veg_diners1=false, $non_veg_diners1=false, $meal_type1=false, $meal_type2=false, $meal_type3=false, $request_type=false, $email=false, $msg=false) {
    
    $baseurl = "https://www.authenticook.com/";
        
    $subject = "Request Date Query for ".$cuisinename." - ".$request_meal_name."";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
      
            <p style="margin:10px 0px;">Hey '.$fname.',</p>
            <p style="margin:10px 0px;">We have received a \'Request Date\' query from you with the following details</p>
          
            <p style="margin:10px 0px;"><b>Name of experience: </b>'.$cuisinename.' - '.$request_meal_name.'</p>
            <p style="margin:10px 0px;"><b>Host: </b>'.$hostname.'</p>
              <p style="margin:10px 0px;"><b>Experience Type: </b><Meal Experience / Activities / Events></p>
              <p style="margin:10px 0px;"><b>Experience Sub Type: </b><Home dining / Cooking class / Food walk></p>

              <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>
            <p style="margin:10px 0px;"><b>Date and Time: </b></p>
            <ul>';
            if(!empty($dateselected1)) {
                $message .= '<li>Option 1 - '.$dateselected1.' - '.$meal_type1;'</li>';
            }
            if(!empty($dateselected2)) {
                $message .= '<li>Option 2 - '.$dateselected2.' - '.$meal_type2;'</li>';
            }
            if(!empty($dateselected3)) {
                $message .= '<li>Option 3 - '.$dateselected3.' - '.$meal_type3;'</li>';
            }
            $message .= '</ul>

            <p style="margin:10px 0px;"><b>Private Dining: </b>'.$request_type.'</p>


            <p style="margin:10px 0px;"><b>Number of seats: </b>'.$totaldiners.'</p>';
            if(!empty($veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$veg_diners1.'</p>';
            }
            if(!empty($non_veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Non Veg Seats : </b>'.$non_veg_diners1.'</p>';
            }


            $message .= '<p style="margin:10px 0px;"><b>Message: </b>'.$msg.'</p>

           


            <p style="margin:10px 0px;">The system has reached out to the home-chef to check for his/her availability for the dates mentioned. On confirmation by the home-chef, you will receive an email with the booking link.</p>

            <p style="margin:10px 0px;">In an event where the home-chef is not available on the said dates, we will suggest a few dates and /or experience other options with you. </p>

            <p style="margin:10px 0px;">It will be our endeavour to make this a memorable experience for you. </p>
            <p style="margin:0px;">If you have any questions or comments, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; font-size: 10px;">You are receiving this email because you signed up for Authenticook. If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';
    echo $message;
 
}
//46. Request Date - On putting a request for an experience. Guest gets email saying their request has been submitted and is awaiting host acceptance
function requestadatemailtohost($cuisinename=false, $request_meal_name=false, $name=false, $city=false, $hostname=false, $dateselected1=false, $dateselected2=false, $dateselected3=false, $veg_diners1=false, $non_veg_diners1=false, $meal_type1=false, $meal_type2=false, $meal_type3=false, $request_type=false, $email=false, $messagereq=false) {
    
    $baseurl = "https://www.authenticook.com/";
    $totaldiners = $veg_diners1 + $non_veg_diners1;
    
       
    $subject = "Request Date Query for ".$cuisinename." - ".$request_meal_name."";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
       
            <p style="margin:10px 0px;">Hey '.$hostname.',</p>
               <p style="margin:10px 0px;">We have received a \'Request Date\' query from you with the following details</p>



            <p style="margin:10px 0px;"><b>Name of experience: </b>'.$cuisinename.' - '.$request_meal_name.'</p>
            <p style="margin:10px 0px;"><b>Host: </b>'.$hostname.'</p>
            <p style="margin:10px 0px;"><b>Experience Type: </b><Meal Experience / Activities / Events></p>

            <p style="margin:10px 0px;"><b>Experience Sub Type: </b>Home dining / Cooking class / Food walk</p>
            <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>

           
               <p style="margin:10px 0px;"><b>Date and Time: </b></p>
            <ul>';
            if(!empty($dateselected1)) {
                $message .= '<li>Option 1 - '.$dateselected1.' - '.$meal_type1;'</li>';
            }
            if(!empty($dateselected2)) {
                $message .= '<li>Option 2 - '.$dateselected2.' - '.$meal_type2;'</li>';
            }
            if(!empty($dateselected3)) {
                $message .= '<li>Option 3 - '.$dateselected3.' - '.$meal_type3;'</li>';
            }
            $message .= '</ul>

             <p style="margin:10px 0px;"><b>Private Dining: </b>Yes/No</p>

            <p style="margin:10px 0px;"><b>No. of seats: </b>'.$totaldiners.'</p>';
            if(!empty($veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$veg_diners1.'</p>';
            }
            if(!empty($non_veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Non Veg Seats: </b>'.$non_veg_diners1.'</p>';
            }


            $message .= '<p style="margin:10px 0px;">The system has reached out to the home-chef to check for his/her availability for the dates mentioned. On confirmation by the home-chef, you will receive an email with the booking link.</p>

   <p style="margin:10px 0px;">In an event where the home-chef is not available on the said dates, we will suggest a few dates and /or experience other options with you.</p>

      <p style="margin:10px 0px;">It will be our endeavour to make this a memorable experience for you.</p>


            <p style="margin:10px 0px;">If you have any questions or comments, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>



     
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
        </div>
    </body>
</html>';
    echo $message;
}


//47 Request Date - After the guest has put in a request, at the same time, Authenticook gets the request email with an option to accept or reject the request

function requestadatemailtoadmin($cuisinename=false, $request_meal_name=false, $name=false, $city=false, $hostname=false, $dateselected1=false, $dateselected2=false, $dateselected3=false, $veg_diners1=false, $non_veg_diners1=false, $meal_type1=false, $meal_type2=false, $meal_type3=false, $messagereq=false, $hostid=false, $pvttxt=false, $ctetxt=false, $urlslug=false, $mealid=false, $typeofdiner=false) {
    
    $baseurl = "https://www.authenticook.com/";
    $totaldiners = $veg_diners1 + $non_veg_diners1;
    
   
    $subject = "Request Date Query for ".$cuisinename." - ".$request_meal_name."";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
            <p style="margin:10px 0px;">Dear Best team in the world,</p>
            <p style="margin:10px 0px;">We have received a Request for a Date with the below mentioned details:</p>
            <p style="margin:10px 0px;"><b>Name of experience: </b><a style="color: #FF5A5A; text-decoration: none;" href="'.$baseurl.'meal/'.$urlslug.'/'.$mealid.'/">'.$cuisinename.' - '.$request_meal_name.'</a></p>
               <p style="margin:10px 0px;"><b>Host: </b><a style="color: #FF5A5A; text-decoration: none;" href="'.$baseurl.'host/'.strtolower($hostname).'/'.$hostid.'/">'.$hostname.'</a></p>
           <p style="margin:10px 0px;"><b>Host: </b>'.$name.'</p>
           <p style="margin:10px 0px;"><b>Experience Type: </b><Meal Experience / Activities / Events></p>
           <p style="margin:10px 0px;"><b>Experience Sub Type: </b>Home dining / Cooking class / Food walk</p>
         
            <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>


            <p style="margin:10px 0px;"><b>Type of Diner: </b>'.$typeofdiner.'</p>
            <p style="margin:10px 0px;"><b>Message: </b>'.$messagereq.'</p>
             


            <p style="margin:10px 0px;"><b>Date and Time: </b></p>
            <ul>';
            if(!empty($dateselected1)) {
                $message .= '<li>Option 1 - '.$dateselected1.' - '.$meal_type1;'</li>';
            }
            if(!empty($dateselected2)) {
                $message .= '<li>Option 2 - '.$dateselected2.' - '.$meal_type2;'</li>';
            }
            if(!empty($dateselected3)) {
                $message .= '<li>Option 3 - '.$dateselected3.' - '.$meal_type3;'</li>';
            }
            $message .= '</ul>
            <p style="margin: 10px 0px;"><b>Private Dining: </b>'.$pvttxt.'</p>
            <p style="margin:10px 0px;"><b>Number of Diners: </b>'.$totaldiners.'</p>';
            if(!empty($veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$veg_diners1.'</p>';
            }
            if(!empty($non_veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Non Veg Seats: <Number of Non Veg Seats/b>'.$non_veg_diners1.'</p>';
            }
            $message .= '
            <p style="margin: 10px 0px;"><b>Houston, we have a solution Request: </b>'.$ctetxt.'</p>
            <p style="margin: 10px 0px;">The following actions are needed from your side</p>
            <ul style="margin: 10px 10px;">
                <li>Accept or Reject the request. On accepting the request, email will be sent the host to Accept, Reject or Provide alternate dates</li>
              
            </ul>

               <p style="margin: 40px 10px 40px 10px;">
          <a style="padding:15px;width:150px!important;background-color: #8bc34a!important;font-style: normal!important;cursor: pointer;border: 1px solid #8bc34a!important;font-family: geogtq_medium;color:#FFF;text-decoration:none" href="'.$baseurl.'profile/" style="color: #FFF; text-decoration: none;">Accept Request</a>
          <a style="padding:15px;width:150px!important;background-color: #F0413C!important;font-style: normal!important;cursor: pointer;border: 1px solid #F0413C!important;font-family: geogtq_medium;color:#FFF;text-decoration:none" href="'.$baseurl.'profile/" style="color: #FFF; text-decoration: none;"> Reject Reques</a>
               </p>





            <p>Thank You</p>
            <p>Jarvis</p>
            <p>Team Authenticooks</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
        </div>
    </body>
</html>';
   echo $message;
}

//48. Request Date - If the request is from a flakey user, AC can reject it where the guest gets an email saying Host has unfortunately had to reject the request

function requestadatemailtouserreject($cuisinename=false, $request_meal_name=false, $fname=false, $name=false, $city=false, $hostname=false, $dateselected1=false, $dateselected2=false, $dateselected3=false, $veg_diners1=false, $non_veg_diners1=false, $meal_type1=false, $meal_type2=false, $meal_type3=false, $request_type=false, $email=false, $msg=false) {
    
    $baseurl = "https://www.authenticook.com/";
        
    $subject = "Update on your request Date Query for ".$cuisinename." - ".$request_meal_name."";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
      
            <p style="margin:10px 0px;">Hey '.$fname.',</p>
            <p style="margin:10px 0px;">This is with regards to the \'Request Date\' query from you with the following details:</p>
          
            <p style="margin:10px 0px;"><b>Name of experience: </b>'.$cuisinename.' - '.$request_meal_name.'</p>

              
              <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>
            <p style="margin:10px 0px;"><b>Date and Time: </b></p>
            <ul>';
            if(!empty($dateselected1)) {
                $message .= '<li>Option 1 - '.$dateselected1.' - '.$meal_type1;'</li>';
            }
            if(!empty($dateselected2)) {
                $message .= '<li>Option 2 - '.$dateselected2.' - '.$meal_type2;'</li>';
            }
            if(!empty($dateselected3)) {
                $message .= '<li>Option 3 - '.$dateselected3.' - '.$meal_type3;'</li>';
            }
            $message .= '</ul>

           

           


            <p style="margin:10px 0px;">Unfortunately, our home-chef is not available to host you on any of these dates, and hence, we can’t go ahead with this request.</p>

            <p style="margin:10px 0px;">Thank you for your time and for reaching out to us.</p>

            <p style="margin:0px;">If you have any questions or comments, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; font-size: 10px;">You are receiving this email because you signed up for Authenticook. If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';
    echo $message;
 
}
// 49. Request Date - Once Authenticook has confirmed the request,  the host gets an email for acceptance or rejection or alternate dates (the host gets an email and is not dependent on AC Accepting)


function requestadatemailtohostacceptanceorrejection($cuisinename=false, $request_meal_name=false, $name=false, $city=false, $hostname=false, $dateselected1=false, $dateselected2=false, $dateselected3=false, $veg_diners1=false, $non_veg_diners1=false, $meal_type1=false, $meal_type2=false, $meal_type3=false, $request_type=false, $email=false, $messagereq=false) {
    
    $baseurl = "https://www.authenticook.com/";
    $totaldiners = $veg_diners1 + $non_veg_diners1;
    
       
    $subject = "Your have received a request for ".$cuisinename." - ".$request_meal_name."";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
       
            <p style="margin:10px 0px;">Hey '.$hostname.',</p>
               <p style="margin:10px 0px;">We have received a \'Request Date\' query from your experience with the following details</p>



            <p style="margin:10px 0px;"><b>Name of experience: </b>'.$cuisinename.' - '.$request_meal_name.'</p>
        
            <p style="margin:10px 0px;"><b>Experience Type: </b><Meal Experience / Activities / Events></p>

            <p style="margin:10px 0px;"><b>Experience Sub Type: </b>Home dining / Cooking class / Food walk</p>
              <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>

           
               <p style="margin:10px 0px;"><b>Date and Time: </b></p>
            <ul>';
            if(!empty($dateselected1)) {
                $message .= '<li>Option 1 - '.$dateselected1.' - '.$meal_type1;'</li>';
            }
            if(!empty($dateselected2)) {
                $message .= '<li>Option 2 - '.$dateselected2.' - '.$meal_type2;'</li>';
            }
            if(!empty($dateselected3)) {
                $message .= '<li>Option 3 - '.$dateselected3.' - '.$meal_type3;'</li>';
            }
            $message .= '</ul>

             <p style="margin:10px 0px;"><b>Private Dining: </b>Yes/No</p>

            <p style="margin:10px 0px;"><b>No. of seats: </b>'.$totaldiners.'</p>';
            if(!empty($veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$veg_diners1.'</p>';
            }
            if(!empty($non_veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Non Veg Seats: </b>'.$non_veg_diners1.'</p>';
            }


            $message .= '<p style="margin:10px 0px;">We would like to know if you can host the guests on any of the dates mentioned above. In case you can’t host on any of the dates, do share with us any other dates that you can host on.</p>

   <p style="margin:10px 0px;">Please let us know, at the earliest, by selecting the preferred dates through the system.</p>

     


        <p style="margin: 40px 10px 40px 10px;">
          <a style="padding:15px;width:150px!important;background-color: #8bc34a!important;font-style: normal!important;cursor: pointer;border: 1px solid #8bc34a!important;font-family: geogtq_medium;color:#FFF;text-decoration:none" href="'.$baseurl.'profile/" style="color: #FFF; text-decoration: none;">Click here to Accept, Reject or Provide Alternate options</a>
   
               </p>



            <p style="margin:10px 0px;">If you have any questions or comments, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>



     
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
        </div>
    </body>
</html>';
    echo $message;
}

//50. Request Date - If host rejects, Authenticook gets an email informing that host has rejected and final overwriting call to be taken
function requestadatemailtohostacceptanceorrejectionto_admin($cuisinename=false, $request_meal_name=false, $name=false, $city=false, $hostname=false, $dateselected1=false, $dateselected2=false, $dateselected3=false, $veg_diners1=false, $non_veg_diners1=false, $meal_type1=false, $meal_type2=false, $meal_type3=false, $request_type=false, $email=false, $messagereq=false) {
    
    $baseurl = "https://www.authenticook.com/";
    $totaldiners = $veg_diners1 + $non_veg_diners1;
    
       
    $subject = "There is a request pending for ".$cuisinename." - ".$request_meal_name."";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
       
            <p style="margin:10px 0px;">Dear Best team in the world,</p>
               <p style="margin:10px 0px;">With regards to the below request, <b>the host has rejected all the date options suggested.</b></b></p>

 <h3>Request Details are:</h3>

            <p style="margin:10px 0px;"><b>Name of experience: </b>'.$cuisinename.' - '.$request_meal_name.'</p>
        
            <p style="margin:10px 0px;"><b>Experience Type: </b><Meal Experience / Activities / Events></p>

            <p style="margin:10px 0px;"><b>Experience Sub Type: </b>Home dining / Cooking class / Food walk</p>
              <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>

           
               <p style="margin:10px 0px;"><b>Date and Time: </b></p>
            <ul>';
            if(!empty($dateselected1)) {
                $message .= '<li>Option 1 - '.$dateselected1.' - '.$meal_type1;'</li>';
            }
            if(!empty($dateselected2)) {
                $message .= '<li>Option 2 - '.$dateselected2.' - '.$meal_type2;'</li>';
            }
            if(!empty($dateselected3)) {
                $message .= '<li>Option 3 - '.$dateselected3.' - '.$meal_type3;'</li>';
            }
            $message .= '</ul>

             <p style="margin:10px 0px;"><b>Private Dining: </b>Yes/No</p>

            <p style="margin:10px 0px;"><b>No. of seats: </b>'.$totaldiners.'</p>';
            if(!empty($veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$veg_diners1.'</p>';
            }
            if(!empty($non_veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Non Veg Seats: </b>'.$non_veg_diners1.'</p>';
            }


            $message .= '<p style="margin:10px 0px;">The following actions are needed from your side</p>


            <ul style="margin: 10px 10px;">
                <li>You will need to click on ‘Close Request’ on the system backend and make it unavailable.</li>
               <li>You can write an email to the guest offering some other experiences.</li>
            </ul>
     


     
            <p>Thank You</p>
            <p>Jarvis</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
        </div>
    </body>
</html>';
    echo $message;
}

//51. Request Date - If dates are accepted or alternate dates are provided, the guest gets an email saying the host has accepted the booking and the email will have a booking link
function requestadatemailtodiner_accepted($cuisinename=false, $request_meal_name=false, $fname=false, $name=false, $city=false, $hostname=false, $dateselected1=false, $dateselected2=false, $dateselected3=false, $veg_diners1=false, $non_veg_diners1=false, $meal_type1=false, $meal_type2=false, $meal_type3=false, $request_type=false, $email=false, $msg=false) {
    
    $baseurl = "https://www.authenticook.com/";
       $totaldiners = $veg_diners1 + $non_veg_diners1;  
    $subject = "Request Date Query for ".$cuisinename." - ".$request_meal_name."";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
      
            <p style="margin:10px 0px;">Hey '.$fname.',</p>
            <p style="margin:10px 0px;">We are glad to inform you that host <first name of the host> is available to host you as per the details given below.</p>

            <p style="margin:10px 0px;">You will need to click on the booking link next to the date mentioned and complete the payment procedure to confirm the booking.</p>

            <p style="margin:10px 0px;">Once completed, you will receive an email via the website with all the details pertaining to the experience including the host location, Google Maps Link and the contact number.</p>

            <p style="margin:10px 0px;">The experience you had selected is</p>
          
            <p style="margin:10px 0px;"><b>Name of experience: </b>'.$cuisinename.' - '.$request_meal_name.'</p>
            <p style="margin:10px 0px;"><b>Host: </b>'.$hostname.'</p>
              <p style="margin:10px 0px;"><b>Experience Type: </b><Meal Experience / Activities / Events></p>
              <p style="margin:10px 0px;"><b>Experience Sub Type: </b><Home dining / Cooking class / Food walk></p>

              <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>
            <p style="margin:10px 0px;"><b>Date and Time: </b></p>
            <ul>';
            if(!empty($dateselected1)) {
                $message .= '<li>Option 1 - '.$dateselected1.' - '.$meal_type1;'</li>';
            }
            if(!empty($dateselected2)) {
                $message .= '<li>Option 2 - '.$dateselected2.' - '.$meal_type2;'</li>';
            }
            if(!empty($dateselected3)) {
                $message .= '<li>Option 3 - '.$dateselected3.' - '.$meal_type3;'</li>';
            }
            $message .= '</ul>

            <p style="margin:10px 0px;"><b>Private Dining: </b>'.$request_type.'</p>


            <p style="margin:10px 0px;"><b>Number of seats: </b>'.$totaldiners.'</p>';
            if(!empty($veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$veg_diners1.'</p>';
            }
            if(!empty($non_veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Non Veg Seats : </b>'.$non_veg_diners1.'</p>';
            }


            $message .= '<p style="margin:10px 0px;">Once you click on ‘Book Now’ you will be directed to the payment gateway.</p>

             <p style="margin:0px;">If you have any questions or comments, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; font-size: 10px;">You are receiving this email because you signed up for Authenticook. If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';
    echo $message;
 
}
// 52. Request Date: If dates are accepted or alternate dates are provided, the admin gets an email saying the host has accepted the booking and the email with the booking link has been sent to the guest

function requestadatemailtohostaccepted_admin($cuisinename=false, $request_meal_name=false, $name=false, $city=false, $hostname=false, $dateselected1=false, $dateselected2=false, $dateselected3=false, $veg_diners1=false, $non_veg_diners1=false, $meal_type1=false, $meal_type2=false, $meal_type3=false, $request_type=false, $email=false, $messagereq=false) {
    
    $baseurl = "https://www.authenticook.com/";
    $totaldiners = $veg_diners1 + $non_veg_diners1;
    
      
    $subject = "Request Date Query for ".$cuisinename." - ".$request_meal_name."";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
       
            <p style="margin:10px 0px;">Dear Best team in the world,</p>
               <p style="margin:10px 0px;">For the below request '.$hostname.' has accepted the request and a booking link has been shared with the requesting guests</p>


            <p style="margin:10px 0px;"><b>Name of experience: </b>'.$cuisinename.' - '.$request_meal_name.'</p>
                  <p style="margin:10px 0px;"><b>Host: </b>'.$hostname.'</p>
            <p style="margin:10px 0px;"><b>Experience Type: </b><Meal Experience / Activities / Events></p>

            <p style="margin:10px 0px;"><b>Experience Sub Type: </b>Home dining / Cooking class / Food walk</p>
              <p style="margin:10px 0px;"><b>City of experience: </b>'.$city.'</p>

           
               <p style="margin:10px 0px;"><b>Date and Time: </b></p>
            <ul>';
            if(!empty($dateselected1)) {
                $message .= '<li>Option 1 - '.$dateselected1.' - '.$meal_type1;'</li>';
            }
            if(!empty($dateselected2)) {
                $message .= '<li>Option 2 - '.$dateselected2.' - '.$meal_type2;'</li>';
            }
            if(!empty($dateselected3)) {
                $message .= '<li>Option 3 - '.$dateselected3.' - '.$meal_type3;'</li>';
            }
            $message .= '</ul>

             <p style="margin:10px 0px;"><b>Private Dining: </b>Yes/No</p>

            <p style="margin:10px 0px;"><b>No. of seats: </b>'.$totaldiners.'</p>';
            if(!empty($veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Veg Seats: </b>'.$veg_diners1.'</p>';
            }
            if(!empty($non_veg_diners1)) {
            $message .= '<p style="margin:10px 0px;"><b>Number of Non Veg Seats: </b>'.$non_veg_diners1.'</p>';
            }


            $message .= '<p style="margin:10px 0px;">The following actions are needed from your side</p>


            <ul style="margin: 10px 10px;">
                <li>You need to reach out to the guest to check if he/she has received the email</li>
               <li>You need to update the home-chef about the status</li>
            </ul>
     


     
            <p>Thank You</p>
            <p>Jarvis</p>
             <p>Team Authenticook</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
        </div>
    </body>
</html>';
    echo $message;
}

// 53. Email which goes to a user who has just registered using an invite link
function newregistrationtodinerby_link($email=false, $name=false) {
    $baseurl = "https://www.authenticook.com/";
  
      
    $subject = "Hey {$name} Get started on Authenticook";
    $message = '<html>
    <body style="margin:0;padding:0;width:100%;margin:auto;">
        <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
            <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
        </div>
        <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
         <p style="margin:10px 0px;">Hey '.$name.',</p>
        <h3>Welcome to the Authenticook community and thank you for signing up through your invite link. </h3>
          
            <p style="margin:10px 0px;">Get ready for experiences which will leave you spellbound. Be it a cooking class, or a food tour or other interesting activities, you will find them here, curated by our amazing hosts. </p>

            <p style="margin:10px 0px;">Before starting your journey, it would be nice if the community could get to know you better. </p>

            <p style="margin:10px 0px;">Complete your profile </p>


             <p>Completing your profile helps build trust in the Authenticook community. (<a href="'.$baseurl.'profile/" style="color: #FF5A5A; text-decoration: none;">Click here</a>)</p>
     <p style="margin:10px 0px;">Check out some of the amazing upcoming experiences!</p>

  <p style="margin:10px 0px;"><4 experiences which are auto updated - one each from meals, activities and events. Incase events are not listed, it could be populated with meal experience of a superhost and be shown here in the form of 2X2 tiles></p>

  <p style="margin:10px 0px;">Want to Invite your friends and family to Authenticook? Get 250 Authenticoins once they complete the experience.</p>


          <p style="padding:15px;width:150px!important;background-color: #F0413C!important;font-style: normal!important;cursor: pointer;border: 1px solid #F0413C!important;font-family: geogtq_medium;color:#FFF"><a href="'.$baseurl.'profile/" style="color: #FFF; text-decoration: none;">Invite your friends</a></p>


            <p style="margin:10px 0px;">Should you have any questions or comments, give us a shout at  <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
            <p style="margin:10px 0px;">We look forward to hosting you soon!</p>
            <p>Team Authenticook</p>
            <p>Eat. Enjoy. Experience.</p>
        </div>
        <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
            <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
            <p style="margin-bottom: 0px;margin-top: 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
        </div>
    </body>
</html>';
   echo $message;
   die;
      // $email_array = array('emailto'=>$emailto,'category'=>$category,'subject'=>$subject,'html'=>$message,'from'=>'contact@authenticook.com','fromname'=>'Authenticook');
// $this.email($email_array);
}









// function forgotpasswordpc($email, $randomnumber) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($email);
//     $mail->addBCC("contact@authenticook.com");
    
//     $mail->Subject = "Reset your Authenticook Password";
//     $mail->Body = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin-top:0px;">Hey there,</p>
//             <p style="margin:10px 0px;">We have received a request to reset the password for your account. Click the button below and reset your password.</p>
//             <p style="margin:10px 0px;">Don\'t you worry, it happens to everyone.</p>
//             <p style="padding: 10px 0px;"><a style="padding: 10px 15px; background-color: #FF5A5A; color: #fff; text-decoration: none;" href="'.$baseurl.'reset-password/'.$randomnumber.'/">Reset your password</a></p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }


// function newregistrationtopartnerchannel($email, $name) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($email);
//     $mail->addBCC("contact@authenticook.com");
    
//     $mail->Subject = "Welcome to Authenticook";
//     $mail->Body = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
//         <h3>Welcome to the Authenticook community!</h3>
//             <p style="margin:10px 0px;">Hello '.$name.',</p>
//             <p style="margin:10px 0px;">Welcome to Authenticook. Thank you for your registration request to join our community.</p>
//             <p style="margin:10px 0px;">As a next step, our representatives will get in touch with you to take the registration process forward and on-board you as Channel Partner. </p>
//             <p style="margin:0px;">Should you have any questions or feedback, please reach us out at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function newregistrationpartnerchanneladmin($organizationname, $individualname, $isd, $phone, $altphone, $address, $email, $faxnumber, $pancardnumber, $website, $userid, $path) {
//     $baseurl = "https://www.authenticook.com/";
//     $newdate = date_create($birthdate);
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress("contact@authenticook.com");
//     $mail->addAttachment($path);
    
//     $mail->Subject = "Registration - New Partner Channel registration on Authenticook";
//     $message = "";
//     $message .= '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <img src="'.$baseurl.'email-images/logo.png">
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
//             <p style="margin:10px 0px;">A new Partner Channel just registered on Authenticook. The details are listed out below:</p>
//             <p style="margin:10px 0px;">Click <a href="'.$baseurl.'authenticook-panel/editpartnerchannel.php?id='.$userid.'" style="color: #FF5A5A; text-decoration: none;">here</a> to view the profile at the backend</p>
//             <p style="margin:10px 0px;"><b>Name of the organization: </b>'.$organizationname.'</p>
//             <p style="margin:10px 0px;"><b>Name of the individual: </b>'.$individualname.'</p>
//             <p style="margin:10px 0px;"><b>Phone Number: </b>'.$isd.' -'.$phone.'</p>
//             <p style="margin:10px 0px;"><b>Alternate Number: </b>'.$altphone.'</p>
//             <p style="margin:10px 0px;"><b>Address: </b>'.$address.'</p>
//             <p style="margin:10px 0px;"><b>Email: </b><a style="color: #FF5A5A; text-decoration: none;">'.$email.'</a></p>
//             <p style="margin:10px 0px;"><b>Fax Number: </b>'.$faxnumber.'</p>
//             <p style="margin:10px 0px;"><b>PAN Card details: </b>'.$pancardnumber.'</p>
//             <p style="margin:10px 0px;"><b>Website: </b>'.$website.'</p>
//             <p style="margin:10px 0px;">You need to contact them and meet them in person to take this forward.</p>
//             <p style="margin:10px 0px;">Thank You,</p>
//             <p style="margin:10px 0px;">Jarvis</p>
//             <p>Team Authenticook</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function newregistrationhostadmin($name, $lname, $isd, $phone, $email, $city, $gender, $birthdate, $userid, $mode, $preference, $arealocality, $transportation, $hometype, $place_to_host_the_diners, $cuisine_specialization, $specialization_description, $pictures_attached) {
//   global $conn;
  
//   $target_dir = "images/host_home_pictures/";
  
//     $baseurl = "https://www.authenticook.com/";
//     $newdate = date_create($birthdate);
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress("contact@authenticook.com");
    
//     $mail->Subject = "Registration - New Host registration on Authenticook";
  
//   $gethomepictures = $conn->query("SELECT image_name FROM tbl_host_details_gallery WHERE user_id = $userid");
//   while($gethomepicturesrow = $gethomepictures->fetch_array()) {
//     $imagename = $gethomepicturesrow['image_name'];
    
//     $mail->addAttachment($target_dir.$imagename);
//   }
  
//     $message = "";
//     $message .= '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <img src="'.$baseurl.'email-images/logo.png">
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
//             <p style="margin:10px 0px;">A new Host just registered on Authenticook. The details are listed out below:</p>
//             <p style="margin:10px 0px;">Click <a href="'.$baseurl.'authenticook-panel/edithost.php?id='.$userid.'" style="color: #FF5A5A; text-decoration: none;">here</a> to view the profile at the back-end</p>
//             <p style="margin:10px 0px;"><b>Name: </b>'.$name.' '.$lname.'</p>
//             <p style="margin:10px 0px;"><b>Phone Number: </b>'.$isd.' - '.$phone.'</p>
//             <p style="margin:10px 0px;"><b>Email: </b><a style="color: #FF5A5A; text-decoration: none;">'.$email.'</a></p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Gender: </b>'.$gender.'</p>
//             <p style="margin:10px 0px;"><b>DOB: </b>'.date_format($newdate, "dS F, Y").'</p>
//             <p style="margin:10px 0px;"><b>Registration Via: </b>'.$mode.'</p>
//       <p style="margin:10px 0px;"><b>Food Preference: </b>'.$preference.'</p>
//       <p style="margin:10px 0px;"><b>Area/Locality: </b>'.$arealocality.'</p>
//       <p style="margin:10px 0px;"><b>Transport availability: </b>'.$transportation.'</p>
//       <p style="margin:10px 0px;"><b>Home Type: </b>'.$hometype.'</p>
//       <p style="margin:10px 0px;"><b>Place to Host the Diners: </b>'.$place_to_host_the_diners.'</p>
//       <p style="margin:10px 0px;"><b>Cuisine Specialization: </b>'.$cuisine_specialization.'</p>
//       <p style="margin:10px 0px;"><b>Why this cuisine: </b>'.$specialization_description.'</p>
//       <p style="margin:10px 0px;"><b>Pictures: </b>'.$pictures_attached.'</p>
//             <p style="margin:10px 0px;">You need to contact the host and meet them in person to take this forward.</p>
//             <p style="margin:10px 0px;">Thank You,</p>
//             <p style="margin:10px 0px;">Jarvis</p>
//             <p>Team Authenticook</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
  
//   $gethomepictures = $conn->query("SELECT image_name FROM tbl_host_details_gallery WHERE user_id = $userid");
//   while($gethomepicturesrow = $gethomepictures->fetch_array()) {
//     $imagename = $gethomepicturesrow['image_name'];
    
//     unlink($target_dir.$imagename);
//   }
// }







// function mealcancellation($fname, $city, $cuisine, $mealname, $host_fname, $email, $path) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($email);
//     $mail->addAttachment($path);
//     $mail->addBCC("contact@authenticook.com");
    
//     $mail->Subject = "Authenticook Meal Cancellation Request";
//     $mail->Body = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Hey '.$fname.',</p>
//             <p style="margin:10px 0px;">We have received a meal cancellation request from you. The details are mentioned below</p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b>'.$cuisine.' - '.$mealname.'</p>
//             <p style="margin:10px 0px;"><b>Host: </b>'.$host_fname.'</p>
//             <p style="margin:10px 0px;">We have shared the information with the host. </p>
//             <p style="margin:10px 0px;">Your refund amount will be as per Authenticook Cancellation & Refund Policy. You will receive a revised confirmation voucher with the updated details. </p>
//             <p style="margin:10px 0px;">Sorry you can\'t make it for this meal. We look forward to having you over for our other experiences. </p>
//             <p style="margin:0px;">If you have any questions or comments, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
//             <p>Till then, Eat well and Live Happy.</p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">You are receiving this email because you signed up for Authenticook. If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';

//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function mealmodificationremovediner($fname, $city, $cuisine, $mealname, $host_fname, $email, $totalcount, $path) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($email);
//     $mail->addAttachment($path);
//     $mail->addBCC("contact@authenticook.com");
    
//     $mail->Subject = "Authenticook Meal Modification Request";
//     $mail->Body = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Hey '.$fname.',</p>
//             <p style="margin:10px 0px;">We have received a meal modification request from you. The details are mentioned below</p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b>'.$cuisine.' - '.$mealname.'</p>
//             <p style="margin:10px 0px;"><b>Host: </b>'.$host_fname.'</p>
//             <p style="margin:10px 0px;">Action: Cancellation of '.$totalcount.' Diner(s)</p>
//             <p style="margin:10px 0px;">Please find attached your confirmation voucher.</p>
//             <p style="margin:10px 0px;">Look forward to having you over at the meal.</p>
//             <p style="margin:0px;">If you have any questions or comments, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';

//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function mealmodificationadddiner($fname, $city, $cuisine, $mealname, $host_fname, $email, $vegdinersmodify, $nonvegdinersmodify, $path) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($email);
//     $mail->addAttachment($path);
//     $mail->addBCC("contact@authenticook.com");
    
//     if(!empty($vegdinersmodify) && !empty($nonvegdinersmodify)) {
//         $additiontext = "Addition of ".$vegdinersmodify." Veg Diner(s) & ".$nonvegdinersmodify." Non-Veg Diner(s)";
//     } else if(!empty($vegdinersmodify) && empty($nonvegdinersmodify)) {
//         $additiontext = "Addition of ".$vegdinersmodify." Veg Diner(s)";
//     } else if(empty($vegdinersmodify) && !empty($nonvegdinersmodify)) {
//         $additiontext = "Addition of ".$nonvegdinersmodify." Non-Veg Diner(s)";
//     }
    
//     $mail->Subject = "Authenticook Meal Modification Request";
//     $mail->Body = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Hey '.$fname.',</p>
//             <p style="margin:10px 0px;">We have received a meal modification request from you. The details are mentioned below</p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b>'.$cuisine.' - '.$mealname.'</p>
//             <p style="margin:10px 0px;"><b>Host: </b>'.$host_fname.'</p>
//             <p style="margin:10px 0px;">Action: '.$additiontext.'</p>
//             <p style="margin:10px 0px;">Please find attached your confirmation voucher.</p>
//             <p style="margin:10px 0px;">Look forward to having you over at the meal.</p>
//             <p style="margin:0px;">If you have any questions or comments, give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';

//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }



// function modificationmailforadminremove($currency, $conversion_rate, $mealname, $cuisinename, $newdate, $username, $hostfname, $host_lname, $hostid, $bookingid, $city, $hostlistingaddress, $mealtype, $vegnonvegtext, $experiencetypepvttext, $experiencetypectetext, $confirmationvouchercode, $totaldiners, $vegdiners, $nonvegdiners, $urlslug, $mealid, $meallistingid, $totalnewdiners, $vegnewdiners, $nonvegnewdiners, $refundamount, $path, $typeofdiner) {
    
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $message = "";
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress("contact@authenticook.com");
//     $mail->addAttachment($path);
//     $mail->Subject = "Meal Modification request for ".$cuisinename." - ".$mealname." on ".date_format($newdate, "l dS F");
//     $message .= '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <img src="'.$baseurl.'email-images/logo.png">
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
//             <p style="margin:10px 0px;">We have received a meal modification request with the below mentioned details</p>
//             <p style="margin:10px 0px;"><b>From: </b>'.$username.'</p>
//             <p style="margin:10px 0px;"><b>Meal Unique Number: </b>'.$bookingid.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b><a href="'.$baseurl.'meal/'.$urlslug.'/'.$mealid.'/'.$meallistingid.'/" style="color: #FF5A5A; text-decoration: none;">'.$mealname.'</a></p>
//             <p style="margin:10px 0px;"><b>Host: </b><a href="'.$baseurl.'host/'.$hostfname.'/'.$hostid.'/" style="color: #FF5A5A; text-decoration: none;">'.$hostfname.' '.$host_lname.'</a></p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Location: </b>'.$hostlistingaddress.'</p>
//             <p style="margin:10px 0px;"><b>Type of Diner: </b>'.$typeofdiner.'</p>
//             <p style="margin:10px 0px;"><b>Date: </b>'.date_format($newdate, "F dS Y").'</p>
//             <p style="margin:10px 0px;"><b>Type: </b>'.$mealtype.'</p>
//             <p style="margin:10px 0px;"><b>Veg or Non-Veg or Both: </b>'.$vegnonvegtext.'</p>
//             <p style="margin:10px 0px;"><b>Action: </b>Cancellation of '.$totaldiners.' Diner(s)</p>
//             <p style="margin:10px 0px;"><b>Private Dining Request: </b>'.$experiencetypepvttext.'</p>
//             <p style="margin:10px 0px;"><b>Houston, we have a solution Request: </b>'.$experiencetypectetext.'</p>
//             <p style="margin:10px 0px;"><b>Confirmation Code: </b>'.$confirmationvouchercode.'</p>
//             <p style="margin:10px 0px;"><b>Refund Amount: </b>'.$currency.' '.number_format(ceil($refundamount/$conversion_rate)).'</p>
//             <p style="margin:10px 0px;"><b>No. of Diners Cancelled: </b>'.$totaldiners.'</p>';
//             if($vegnonvegtext == "Both") {
//                 $message .= '<p style="margin:10px 0px;"><b>Cancelled Veg: </b>'.$vegdiners.'</p>
//                 <p style="margin:10px 0px;"><b>Cancelled Non-Veg: </b>'.$nonvegdiners.'</p>';
//             } else if($vegnonvegtext == "Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Cancelled Veg: </b>'.$vegdiners.'</p>';
//             } else if($vegnonvegtext == "Non-Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Cancelled Non-Veg: </b>'.$nonvegdiners.'</p>';
//             }
    
//             $message .= '<p style="margin:10px 0px;"><b>Post Modification No. of Diners: </b>'.$totalnewdiners.'</p>';
//             if($vegnonvegtext == "Both") {
//                 $message .= '<p style="margin:10px 0px;"><b>Post Modification No. of Veg Diners: </b>'.$vegnewdiners.'</p>
//                 <p style="margin:10px 0px;"><b>Post Modification No. of Non-Veg Diners: </b>'.$nonvegnewdiners.'</p>';
//             } else if($vegnonvegtext == "Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Post Modification No. of Veg Diners: </b>'.$vegnewdiners.'</p>';
//             } else if($vegnonvegtext == "Non-Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Post Modification No. of Non-Veg Diners: </b>'.$nonvegnewdiners.'</p>';
//             }
    
//             $message .= '
//             <p style="margin:10px 0px;">The following actions are needed from your side</p>
//             <ul>
//                 <li>You need to reach out to the Host '.$hostfname.' to inform her about this meal</li>
//                 <li>Also need to check in case of seat cancellation, whether it impacts the minimum seating criteria and proceed accordingly</li>
//                 <li>And finally, you need to refund the amount as per the Cancellation and Refund Policy in case of cancellation </li>
//             </ul>
//             <p style="margin:10px 0px;">Thank You,</p>
//             <p style="margin:10px 0px;">Jarvis</p>
//             <p>Team Authenticook</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function cancellationmailforadmin($currency, $conversion_rate, $mealname, $cuisinename, $newdate, $username, $bookingid, $hostfname, $host_lname, $hostid, $city, $hostlistingaddress, $mealtype, $vegnonvegtext, $experiencetypepvttext, $experiencetypectetext, $confirmationvouchercode, $totaldinerscancelled, $vegdiners, $nonvegdiners, $urlslug, $mealid, $meallistingid, $refundamount, $path, $typeofdiner) {
    
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $message = "";
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress("contact@authenticook.com");
//     $mail->addAttachment($path);
//     $mail->Subject = "Meal Cancellation request for ".$cuisinename." - ".$mealname." on ".date_format($newdate, "l dS F");
//     $message .= '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <img src="'.$baseurl.'email-images/logo.png">
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
//             <p style="margin:10px 0px;">We have received a meal cancellation request with the below mentioned details</p>
//             <p style="margin:10px 0px;"><b>From: </b>'.$username.'</p>
//             <p style="margin:10px 0px;"><b>Meal Unique Number: </b>'.$bookingid.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b><a href="'.$baseurl.'meal/'.$urlslug.'/'.$mealid.'/'.$meallistingid.'/" style="color: #FF5A5A; text-decoration: none;">'.$mealname.'</a></p>
//             <p style="margin:10px 0px;"><b>Host: </b><a href="'.$baseurl.'host/'.$hostfname.'/'.$hostid.'/" style="color: #FF5A5A; text-decoration: none;">'.$hostfname.' '.$host_lname.'</a></p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Location: </b>'.$hostlistingaddress.'</p>
//             <p style="margin:10px 0px;"><b>Type of Diner: </b>'.$typeofdiner.'</p>
//             <p style="margin:10px 0px;"><b>Date: </b>'.date_format($newdate, "F dS Y").'</p>
//             <p style="margin:10px 0px;"><b>Type: </b>'.$mealtype.'</p>
//             <p style="margin:10px 0px;"><b>Veg or Non-Veg or Both: </b>'.$vegnonvegtext.'</p>
//             <p style="margin:10px 0px;"><b>Action: </b>Meal Cancellation</p>
//             <p style="margin:10px 0px;"><b>Originally Private Dining Request: </b>'.$experiencetypepvttext.'</p>
//             <p style="margin:10px 0px;"><b>Originally Houston, we have a solution Request: </b>'.$experiencetypectetext.'</p>
//             <p style="margin:10px 0px;"><b>Original Confirmation Code: </b>'.$confirmationvouchercode.'</p>
//             <p style="margin:10px 0px;"><b>Refund Amount: </b>'.$currency.' '.number_format(ceil($refundamount/$conversion_rate)).'</p>
//             <p style="margin:10px 0px;"><b>No. of Diners Cancelled: </b>'.$totaldinerscancelled.'</p>';
//             if($vegnonvegtext == "Both") {
//                 $message .= '<p style="margin:10px 0px;"><b>Cancelled Veg: </b>'.$vegdiners.'</p>
//                 <p style="margin:10px 0px;"><b>Cancelled Non-Veg: </b>'.$nonvegdiners.'</p>';
//             } else if($vegnonvegtext == "Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Cancelled Veg: </b>'.$vegdiners.'</p>';
//             } else if($vegnonvegtext == "Non-Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Cancelled Non-Veg: </b>'.$nonvegdiners.'</p>';
//             }
    
//             $message .= '
//             <p style="margin:10px 0px;">The following actions are needed from your side</p>
//             <ul>
//                 <li>You need to reach out to the Host '.$hostfname.' to inform her about this meal</li>
//                 <li>Also need to check if the meal cancellation impacts the minimum seating criteria and proceed accordingly</li>
//                 <li>And finally, you need to refund the amount as per the Cancellation and Refund Policy</li>
//             </ul>
//             <p style="margin:10px 0px;">Thank You,</p>
//             <p style="margin:10px 0px;">Jarvis</p>
//             <p>Team Authenticook</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function modificationmailforadminadd($currency, $conversion_rate, $mealname, $cuisinename, $newdate, $username, $hostfname, $host_lname, $hostid, $bookingid, $city, $hostlistingaddress, $mealtype, $vegnonvegtext, $experiencetypepvttext, $experiencetypectetext, $confirmationvouchercode, $totaldiners, $vegdiners, $nonvegdiners, $urlslug, $mealid, $meallistingid, $totalnewdiners, $vegnewdiners, $nonvegnewdiners, $path, $additionalamount, $mealmindiners, $typeofdiner) {
    
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $message = "";
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress("contact@authenticook.com");
//     $mail->addAttachment($path);
    
//     $mail->Subject = "Meal Modification request for ".$cuisinename." - ".$mealname." on ".date_format($newdate, "l dS F");
//     $message .= '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <img src="'.$baseurl.'email-images/logo.png">
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
//             <p style="margin:10px 0px;">We have received a meal modification request with the below mentioned details</p>
//             <p style="margin:10px 0px;"><b>From: </b>'.$username.'</p>
//             <p style="margin:10px 0px;"><b>Meal Unique Number: </b>'.$bookingid.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b><a href="'.$baseurl.'meal/'.$urlslug.'/'.$mealid.'/'.$meallistingid.'/" style="color: #FF5A5A; text-decoration: none;">'.$mealname.'</a></p>
//             <p style="margin:10px 0px;"><b>Host: </b><a href="'.$baseurl.'host/'.$hostfname.'/'.$hostid.'/" style="color: #FF5A5A; text-decoration: none;">'.$hostfname.' '.$host_lname.'</a></p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Location: </b>'.$hostlistingaddress.'</p>
//             <p style="margin:10px 0px;"><b>Type of Diner: </b>'.$typeofdiner.'</p>
//             <p style="margin:10px 0px;"><b>Date: </b>'.date_format($newdate, "F dS Y").'</p>
//             <p style="margin:10px 0px;"><b>Type: </b>'.$mealtype.'</p>
//             <p style="margin:10px 0px;"><b>Veg or Non-Veg or Both: </b>'.$vegnonvegtext.'</p>
//             <p style="margin:10px 0px;"><b>Action: </b>Addition of '.$totalnewdiners.' Diner(s)</p>
//             <p style="margin:10px 0px;"><b>Private Dining Request: </b>'.$experiencetypepvttext.'</p>
//             <p style="margin:10px 0px;"><b>Houston, we have a solution Request: </b>'.$experiencetypectetext.'</p>
//             <p style="margin:10px 0px;"><b>Confirmation Code: </b>'.$confirmationvouchercode.'</p>';
//             if(($experiencetypepvttext || $experiencetypectetext) == "Yes") {
//                 if($totaldiners < $mealmindiners) {
//                     if($additionalamount > 0) {
//                         $message .='<p style="margin:10px 0px;"><b>Additional Amount: </b>'.$currency.' '.number_format(ceil($additionalamount/$conversion_rate)).'</p>';
//                     }
//                 }
//             }
//             $message .='<p style="margin:10px 0px;"><b>No. of Diners added: </b>'.$totalnewdiners.'</p>';
//             if($vegnonvegtext == "Both") {
//                 $message .= '<p style="margin:10px 0px;"><b>Added Veg: </b>'.$vegnewdiners.'</p>
//                 <p style="margin:10px 0px;"><b>Added Non-Veg: </b>'.$nonvegnewdiners.'</p>';
//             } else if($vegnonvegtext == "Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Added Veg: </b>'.$vegnewdiners.'</p>';
//             } else if($vegnonvegtext == "Non-Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Added Non-Veg: </b>'.$nonvegnewdiners.'</p>';
//             }
    
//             $message .= '<p style="margin:10px 0px;"><b>Post Modification No. of Diners: </b>'.$totaldiners.'</p>';
//             if($vegnonvegtext == "Both") {
//                 $message .= '<p style="margin:10px 0px;"><b>Post Modification No. of Veg Diners: </b>'.$vegdiners.'</p>
//                 <p style="margin:10px 0px;"><b>Post Modification No. of Non-Veg Diners: </b>'.$nonvegdiners.'</p>';
//             } else if($vegnonvegtext == "Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Post Modification No. of Veg Diners: </b>'.$vegdiners.'</p>';
//             } else if($vegnonvegtext == "Non-Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Post Modification No. of Non-Veg Diners: </b>'.$nonvegdiners.'</p>';
//             }
    
//             $message .= '
//             <p style="margin:10px 0px;">The following actions are needed from your side</p>
//             <ul>
//                 <li>You need to reach out to the Host '.$hostfname.' to inform her about this meal</li>
//             </ul>
//             <p style="margin:10px 0px;">Thank You,</p>
//             <p style="margin:10px 0px;">Jarvis</p>
//             <p>Team Authenticook</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function abandonedcart($conn, $mealname, $cuisinename, $newdate, $username, $hostfname, $hostlname, $bookingid, $city, $typeofmeal, $vegnonvegtext, $experiencetypepvttext, $experiencetypectetext, $totaldiners, $vegdiners, $nonvegdiners, $urlslug, $mealid, $meallistingid, $promocode, $experiencetype, $discountpercent, $typeofdiner, $typeofbooking) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $message = "";
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress("contact@authenticook.com");
    
//     if($totaldiners == 1) {
//         $seattext = "seat";
//     } else {
//         $seattext = "seats";
//     }
    
//     $mail->Subject = $typeofbooking." Failed for ".$totaldiners." ".$seattext." for ".$cuisinename." - ".$mealname." on ".date_format($newdate, "dS F, Y");
//     $message .= '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <img src="'.$baseurl.'email-images/logo.png">
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
//             <p style="margin:10px 0px;">We have noticed that someone attempted a booking on our website; the details of the pending booking are as below:</p>
//             <p style="margin:10px 0px;"><b>From: </b>'.$username.'</p>
//             <p style="margin:10px 0px;"><b>Date: </b>'.date_format($newdate, "F dS Y").'</p>
//       <p style="margin:10px 0px;"><b>Type of Meal: </b>'.$typeofmeal.'</p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Type of Diner: </b>'.$typeofdiner.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b><a href="'.$baseurl.'meal/'.$urlslug.'/'.$mealid.'/'.$meallistingid.'/" style="color: #FF5A5A; text-decoration: none;">'.$mealid.' - '.$mealname.'</a></p>
//             <p style="margin:10px 0px;"><b>Meal Booking Unique Number: </b>'.$bookingid.'</p>
//             <p style="margin:10px 0px;"><b>Host: </b>'.$hostfname.' '.$hostlname.'</p>
//             <p style="margin:10px 0px;"><b>Action: </b>'.$typeofbooking.'</p>
//             <p style="margin:10px 0px;"><b>Private Dining Request: </b>'.$experiencetypepvttext.'</p>
//             <p style="margin:10px 0px;"><b>Houston, we have a solution Request: </b>'.$experiencetypectetext.'</p>';
//             $message .='<p style="margin:10px 0px;"><b>Number of seats attempted: </b>'.$totaldiners.'</p>';
//             if($vegnonvegtext == "Both") {
//                 $message .= '<p style="margin:10px 0px;"><b>Veg: </b>'.$vegdiners.'</p>
//                 <p style="margin:10px 0px;"><b>Non-Veg: </b>'.$nonvegdiners.'</p>';
//             } else if($vegnonvegtext == "Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Veg: </b>'.$vegdiners.'</p>';
//             } else if($vegnonvegtext == "Non-Veg") {
//                 $message .= '<p style="margin:10px 0px;"><b>Non-Veg: </b>'.$nonvegdiners.'</p>';
//             }
    
//             $message .= '
//             <p style="margin:10px 0px;"><b>Promo Code: </b>'.$promocode.'</p>
//             <p style="margin:10px 0px;"><b>Experience Type: </b>'.$experiencetype.'</p>';
//             $message .= '<p style="margin:10px 0px;"><b>Discount: </b>'.$discountpercent.'%</p>
//             <p style="margin:10px 0px;">Thank You,</p>
//             <p style="margin:10px 0px;">Jarvis</p>
//             <p>Team Authenticook</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function ratingnotification($mealrating, $hosting_rating, $location_rating, $value_rating, $mealreview, $mealname, $cuisinename, $newdate, $username, $hostfname, $hostlname, $bookingid, $city, $typeofmeal, $experiencetypepvttext, $experiencetypectetext, $urlslug, $mealid, $meallistingid, $experiencetype, $typeofdiner) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $message = "";
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress("contact@authenticook.com");
    
//     $mail->Subject = "Rating for ".$cuisinename." - ".$mealname." on ".date_format($newdate, "dS F, Y");
//     $message .= '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <img src="'.$baseurl.'email-images/logo.png">
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin-top:0px;">Dear \'Best team in the world\',</p>
//             <p style="margin:10px 0px;">We have noticed that someone has put in a review for one the attended meals on our website; the details of the booking are as below:</p>
//             <p style="margin:10px 0px;"><b>From: </b>'.$username.'</p>
//       <p style="margin:10px 0px;"><b>Food: </b>'.$mealrating.'</p>
//       <p style="margin:10px 0px;"><b>Hosting: </b>'.$hosting_rating.'</p>
//       <p style="margin:10px 0px;"><b>Location: </b>'.$location_rating.'</p>
//       <p style="margin:10px 0px;"><b>Value: </b>'.$value_rating.'</p>
//       <p style="margin:10px 0px;"><b>Review provided: </b>'.$mealreview.'</p>
//             <p style="margin:10px 0px;"><b>Date: </b>'.date_format($newdate, "F dS Y").'</p>
//       <p style="margin:10px 0px;"><b>Type of Meal: </b>'.$typeofmeal.'</p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Type of Diner: </b>'.$typeofdiner.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b><a href="'.$baseurl.'meal/'.$urlslug.'/'.$mealid.'/'.$meallistingid.'/" style="color: #FF5A5A; text-decoration: none;">'.$mealid.' - '.$mealname.'</a></p>
//             <p style="margin:10px 0px;"><b>Meal Booking Unique Number: </b>'.$bookingid.'</p>
//             <p style="margin:10px 0px;"><b>Host: </b>'.$hostfname.' '.$hostlname.'</p>
//             <p style="margin:10px 0px;"><b>Private Dining Request: </b>'.$experiencetypepvttext.'</p>
//             <p style="margin:10px 0px;"><b>Houston, we have a solution Request: </b>'.$experiencetypectetext.'</p>
//             <p style="margin:10px 0px;">Thank You,</p>
//             <p style="margin:10px 0px;">Jarvis</p>
//             <p>Team Authenticook</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function customemail($email, $subject, $message, $path) {
//     $message = htmlspecialchars($message);
//     $message = htmlspecialchars_decode($message);
    
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($email);
//     $mail->addAttachment($path);
//     $mail->addBCC("contact@authenticook.com");
    
//     $mail->Subject = $subject;
//     $mail->Body = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:0 25px;border:1px solid #FF5A5A;border-top:0px;padding-top:15px;">
//             '.$message.'
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; font-size: 10px;">If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';
    
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function mealreminder($email, $username, $newdate, $cuisinename, $mealname, $hostfname, $totaldiners, $googlemapslink, $dinerdetails, $path, $location = 1) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($email);
//     $mail->addBCC("contact@authenticook.com");
//     $mail->addAttachment($path);

//     /* Anil */
//     switch ($location) 
//     {
//         case '1':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '2':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '3':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g303877-d13307234-Reviews-Authenticook-Panjim_North_Goa_District_Goa.html';
//         break;
//         case '4':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304551-d13387658-Reviews-Authenticook-New_Delhi_National_Capital_Territory_of_Delhi.html';
//         break;
//         case '5':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g297633-d13387673-Reviews-Authenticook-Kochi_Cochin_Kerala.html';
//         break;
//         case '6':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g12413370-d13387674-Reviews-Authenticook-Udaipur_District_Rajasthan.html';
//         break;
//         case '7':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304555-d13385736-Reviews-Authenticook-Jaipur_Jaipur_District_Rajasthan.html';
//         break;
//         case '9':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g297628-d13412601-Reviews-Authenticook-Bengaluru_Bangalore_District_Karnataka.html';
//         break;
//         case '10':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '11':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '12':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '13':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304556-d13412427-Reviews-Authenticook-Chennai_Madras_Chennai_District_Tamil_Nadu.html';
//         break;
//         case '14':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g659792-d13412610-Reviews-Authenticook-Pondicherry_Union_Territory_of_Pondicherry.html';
//         break;
//         case '15':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g297684-d13167010-Reviews-Authenticook-Lucknow_Lucknow_District_Uttar_Pradesh.html';
//         break;
//         case '16':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         default:
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//     }
//     /* Anil */
    
//     $mail->Subject = "Are you geared up for your Authenticook meal";
//     $message = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Hey '.$username.',</p>
//             <p style="margin:10px 0px;">You have a meal coming up! The details are:</p>
//             <p style="margin:10px 0px;"><b>Meal Date: </b>'.date_format($newdate, "F dS, Y").'</p>
//             <p style="margin:10px 0px;"><b>Meal Experience: </b>'.$cuisinename.' - '.$mealname.'</p>
//             <p style="margin:10px 0px;"><b>Host name: </b>'.$hostfname.'</p>
//             <p style="margin:10px 0px;"><b>Total Number of Diners: </b>'.$totaldiners.'</p>
//             <p style="margin:10px 0px;"><b>Location: </b>'.$googlemapslink.'</p>';
//             if(!empty($dinerdetails)) { $message .= '<p style="margin:10px 0px;"><b>Fellow Diners Attending the meal: </b><br>'.$dinerdetails.'</p>'; }
//             $message .= '<p style="margin:10px 0px;">Also, please find attached your confirmation voucher.</p>
//             <p style="margin:10px 0px;">Also, <a href="'.$baseurl.'to-dos/" style="color: #FF5A5A; text-decoration: none;">click here</a> to find some useful tips on how you can enjoy your experience to the fullest.</p>
//             <p style="margin:0px;">We would love to hear from you after the experience. Feel free to</p>
//             <ul>
//                 <li>Share pictures from the meal on Facebook (don\'t forget to tag Authenticook); AND</li>
//                 <li>Put up a nice review for Authenticook on Tripadvisor which would help us in understanding what we are doing right and what we need to improve upon; you can put this up on the following link <a style="color: #FF5A5A; text-decoration: none;" href="'.$trip_place.'">Authenticook Tripadvisor Review</a></li>
//             </ul>
//             <p style="margin:0px;">Once done, just give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a> to receive your promocode.</p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">You are receiving this email because you signed up for Authenticook. If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function postmealemail($email, $userfname, $cuisinename, $meallistingid, $location = 1) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($email);
//     $mail->addBCC("contact@authenticook.com");

//     /* Anil */
//     switch ($location) 
//     {
//         case '1':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '2':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '3':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g303877-d13307234-Reviews-Authenticook-Panjim_North_Goa_District_Goa.html';
//         break;
//         case '4':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304551-d13387658-Reviews-Authenticook-New_Delhi_National_Capital_Territory_of_Delhi.html';
//         break;
//         case '5':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g297633-d13387673-Reviews-Authenticook-Kochi_Cochin_Kerala.html';
//         break;
//         case '6':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g12413370-d13387674-Reviews-Authenticook-Udaipur_District_Rajasthan.html';
//         break;
//         case '7':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304555-d13385736-Reviews-Authenticook-Jaipur_Jaipur_District_Rajasthan.html';
//         break;
//         case '9':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g297628-d13412601-Reviews-Authenticook-Bengaluru_Bangalore_District_Karnataka.html';
//         break;
//         case '10':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '11':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '12':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         case '13':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304556-d13412427-Reviews-Authenticook-Chennai_Madras_Chennai_District_Tamil_Nadu.html';
//         break;
//         case '14':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g659792-d13412610-Reviews-Authenticook-Pondicherry_Union_Territory_of_Pondicherry.html';
//         break;
//         case '15':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g297684-d13167010-Reviews-Authenticook-Lucknow_Lucknow_District_Uttar_Pradesh.html';
//         break;
//         case '16':
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//         default:
//             $trip_place = 'https://www.tripadvisor.in/Attraction_Review-g304554-d13121196-Reviews-Authenticook-Mumbai_Maharashtra.html';
//         break;
//     }
//     /* Anil */
    
//     $mail->Subject = "Hope you enjoyed your Authenticook meal";
//     $message = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Hey '.$userfname.',</p>
//             <p style="margin:10px 0px;">Hope you enjoyed the '.$cuisinename.' experience.</p>
//             <p style="margin:10px 0px;">Your hosts are eagerly waiting to hear about your experience.</p>
//             <p style="margin:10px 0px;">We would be grateful if you could please leave a review on <a href="'.$baseurl.'rating-review/'.$meallistingid.'/" style="color: #FF5A5A; text-decoration: none;">Authenticook</a> and <a href="'.$trip_place.'" style="color: #FF5A5A; text-decoration: none;">Tripadvisor</a>. Your review will help us improve and help future guests while choosing an experience.</p>
//             <p style="margin:10px 0px;">Look forward to seeing you soon.</p>
//             <p style="margin:10px 0px;">For any queries, get in touch <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">You are receiving this email because you signed up for Authenticook. If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function mailsummaryforhost($starttime, $endtime, $cuisineid, $conn, $meallistingid, $mealid, $newdate, $hostid) {
//     $bookinglist = $conn->query("SELECT user_id, partner_channel_id, user_type, veg_diners, non_veg_diners, unique_confirmation_code FROM tbl_booking WHERE meal_listing_id = '$meallistingid' AND payment_status = 'Received'");
    
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
    
//     $hostdetails = $conn->query("SELECT host_fname, host_lname, host_email, host_city, host_isd_code, host_mobile FROM tbl_host WHERE id = '$hostid'");
//     $hostrow = $hostdetails->fetch_array();
//     $hostfname = $hostrow['host_fname'];
//     $hostlname = $hostrow['host_lname'];
//     $host_email = $hostrow['host_email'];
//     $host_city = $hostrow['host_city'];
//   $hostisdcode = $hostrow['host_isd_code'];
//   $hostmobile = $hostrow['host_mobile'];
    
//     $hostcurrencyiddetails = $conn->query("SELECT currency FROM tbl_location WHERE id = $host_city");
//     $hostcurrencyidrow = $hostcurrencyiddetails->fetch_array();
//     $hostcurrencyid = $hostcurrencyidrow['currency'];
    
//     $currencyconversion = $conn->query("SELECT currency_name, font_awesome_code, conversion FROM tbl_currency WHERE id = $hostcurrencyid");
//     $currencyconversionrow = $currencyconversion->fetch_array();
//     $currency_name = $currencyconversionrow['currency_name'];
//     $conversion_rate = $currencyconversionrow['conversion'];

//     $cuisinedetails = $conn->query("SELECT cuisine_name FROM tbl_cuisine WHERE id = '$cuisineid'");
//     $cuisinerow = $cuisinedetails->fetch_array();
//     $cuisinename = $cuisinerow['cuisine_name'];

//     $mealdetails = $conn->query("SELECT name, veg_price, non_veg_price FROM tbl_meal WHERE id = '$mealid'");
//     $mealrow = $mealdetails->fetch_array();
//     $mealname = $mealrow ['name'];
//     $mealvegprice = $mealrow['veg_price'];
//     $mealnonvegprice = $mealrow['non_veg_price'];
    
//     $mail->addAddress($host_email);
//     $mail->addBCC("contact@authenticook.com");
    
//     $bookingcategories = $conn->query("SELECT veg_diners, non_veg_diners FROM tbl_booking WHERE meal_listing_id = '$meallistingid' AND payment_status = 'Received'");
//     while($bookingcatrow = $bookingcategories->fetch_array()) {
//         $vegdiners += $bookingcatrow['veg_diners'];
//         $nonvegdiners += $bookingcatrow['non_veg_diners'];
//     }
    
//     $totalbookings = $vegdiners + $nonvegdiners;
    
//     if($totalbookings == 1) {
//         $bookingtext = "booking";
//     } else {
//         $bookingtext = "bookings";
//     }

//     $formtext = "0 diners";
    
//     $totalamountarray = ($mealvegprice * $vegdiners) + ($mealnonvegprice * $nonvegdiners);
    
//     $mail->Subject = "Diner Details for ".$cuisinename." - ".$mealname." on ".date_format($newdate, "F dS, Y");
//     $message = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Dear '.$hostfname.',</p>
//             <p style="margin:10px 0px;">This is to inform you that we have received '.$totalbookings.' '.$bookingtext.' for your \''.$cuisinename.' - '.$mealname.'\' experience. </p>
//             <p style="margin:10px 0px;">Experience Date: '.date_format($newdate, "l, F d, Y").'</p>
//             <p style="margin:10px 0px;">Start Time: '.converttoampm($starttime).'</p>
//             <p style="margin:10px 0px;">End Time: '.converttoampm($endtime).'</p>
//             <p style="margin:10px 0px;">Number of Diners Confirmed: '.$totalbookings.'</p>';
//             if(!empty($totalbookings)) {
//             $message .= '<p style="margin:10px 0px;"><i>Please see below the details of all the diners.</i></p>
//             <table style="width:100%;border-top:1px solid #FF5A5A;border-spacing:0px;margin:25px auto;cell-padding:0px;">
//                 <tbody>
//                     <tr style="line-height:30px;font-family:geogtq_regular;">
//                         <td style="width:30%;border-bottom:1px solid #FF5A5A;padding:2px 5px;"><b>Name*</b></td>
//                         <td style="width:10%;border-bottom:1px solid #FF5A5A;padding:2px 5px;"><b>Gender*</b></td>';
//                         if($vegdiners != 0) { $message .= '<td style="width:20%;border-bottom:1px solid #FF5A5A;padding:2px 5px;"><b>V Diners</b></td>'; }
//                         if($nonvegdiners != 0) { $message .= '<td style="width:20%;border-bottom:1px solid #FF5A5A;padding:2px 5px;"><b>N-V Diners</b></td>'; }
//                         $message .= '<td style="width:20%;padding:2px 5px;border-bottom:1px solid #FF5A5A;"><b>Confirmation Code</b></td>
//                     </tr>';
//           $veg_diners_array = array();
//           $non_veg_diners_array = array();
//                     while($bookingrow = $bookinglist->fetch_array()) {
//                         $userid = $bookingrow['user_id'];
//                         $partnerchannelid = $bookingrow['partner_channel_id'];
//                         $usertype = $bookingrow['user_type'];
//                         $veg_diners = $bookingrow['veg_diners'];
//                         $non_veg_diners = $bookingrow['non_veg_diners'];
//                         $totaldiners = $veg_diners + $non_veg_diners;
//                         $unique_confirmation_code = $bookingrow['unique_confirmation_code'];
//             $veg_diners_array[] = $veg_diners;
//             $non_veg_diners_array[] = $non_veg_diners;
                        
//                         if($usertype == 3) {
//                             $partnerchanneldetails = $conn->query("SELECT organization FROM tbl_partner_channel WHERE id = '$partnerchannelid'");
//                             $partnerchannelrow = $partnerchanneldetails->fetch_array();
//                             $username = $partnerchannelrow['organization'];
//                             $totaldiners = " ".$totaldiners ." Guest";
//                         } else {
//                             $userdetails = $conn->query("SELECT user_fname, user_lname, user_gender FROM tbl_registered_users WHERE id = '$userid'");
//                             $userrow = $userdetails->fetch_array();
//                             $userfname = $userrow['user_fname'];
//                             $userlname = $userrow['user_lname'];
//                             $username = $userfname." ".$userlname;
//                             $usergender = $userrow['user_gender'];
//                             if($totaldiners != 1) {
//                                 $newnumber = $totaldiners - 1;
//                                 $totaldiners = " +".$newnumber;
//                             } else {
//                                 $totaldiners = "";
//                             }
//                         }
                        
//                         if($veg_diners != 0 && $non_veg_diners != 0) {
//                             $categorytext = "Veg & Non-Veg";
//                         } else if($veg_diners != 0) {
//                             $categorytext = "Veg";
//                         } else if($non_veg_diners != 0) {
//                             $categorytext = "Non Veg";
//                         }
//                     $message .= '    
//                     <tr style="line-height:30px;font-family:geogtq_regular;">
//                         <td style="width:30%;border-bottom:1px solid #FF5A5A;padding:2px 5px;">'.$username.$totaldiners.'</td>
//                         <td style="width:10%;border-bottom:1px solid #FF5A5A;padding:2px 5px;">'.$usergender.'</td>';
//                         if($vegdiners != 0) { $message .= '<td style="width:20%;border-bottom:1px solid #FF5A5A;padding:2px 5px;">'.$veg_diners.'</td>'; }
//                         if($nonvegdiners != 0) { $message .= '<td style="width:20%;border-bottom:1px solid #FF5A5A;padding:2px 5px;">'.$non_veg_diners.'</td>'; }
//                         $message .= '<td style="width:20%;padding:2px 5px;border-bottom:1px solid #FF5A5A;">'.$unique_confirmation_code.'</td>
//                     </tr>';
//                     }
        
//         $veg_diners_total_diners = array_sum($veg_diners_array);
//         $non_veg_diners_total_diners = array_sum($non_veg_diners_array);
        
//         if(!empty($veg_diners_total_diners) && !empty($non_veg_diners_total_diners)) {
//           $formtext = $veg_diners_total_diners." Veg, ".$non_veg_diners_total_diners." Non-Veg";
//         } else if(!empty($veg_diners_total_diners) && empty($non_veg_diners_total_diners)) {
//           $formtext = $veg_diners_total_diners." Veg";
//         } else if(empty($veg_diners_total_diners) && !empty($non_veg_diners_total_diners)) {
//           $formtext = $non_veg_diners_total_diners." Non-Veg";
//         } else {
//             $formtext = "0 diners";
//         }
//                 $message .= '</tbody>
//             </table>
//             <p style="margin:10px 0px;"><b>*</b> Details provided of registered diner(s)</p>
//             <p style="margin:10px 0px;">V Diners - Veg Diners</p>
//             <p style="margin:10px 0px;">N-V Diners - Non-Veg Diners</p>
//             <p style="margin:10px 0px;">(We will reach out to you separately for any food related allergies of diners)</p>
//             <p style="margin:10px 0px;">Billing</p>
//             <table style="width:100%;border-top:1px solid #FF5A5A;border-spacing:0px;margin:25px auto;cell-padding:0px;">
//                 <tbody>';
//                     $totalvegamount = $mealvegprice * $vegdiners;
//                     $totalnonvegamount = $mealnonvegprice * $nonvegdiners;
    
//                     if($vegdiners != 0) {
//                     $message .='<tr style="line-height:30px;font-family:geogtq_regular;">
//                         <td style="width:70%;border-bottom:1px solid #FF5A5A;padding:2px 5px;">'.$currency_name.'. '.number_format(ceil($mealvegprice/$conversion_rate)).' x '.$vegdiners.' Veg diners</td>
//                         <td style="width:30%;border-bottom:1px solid #FF5A5A;padding:2px 5px;">'.$currency_name.'. '.number_format(ceil($totalvegamount/$conversion_rate)).'</td>
//                     </tr>'; }
//                     if($nonvegdiners != 0) {
//                     $message .='<tr style="line-height:30px;font-family:geogtq_regular;">
//                         <td style="width:70%;border-bottom:1px solid #FF5A5A;padding:2px 5px;">'.$currency_name.'. '.number_format(ceil($mealnonvegprice/$conversion_rate)).' x '.$nonvegdiners.' Non-Veg diners</td>
//                         <td style="width:30%;border-bottom:1px solid #FF5A5A;padding:2px 5px;">'.$currency_name.'. '.number_format(ceil($totalnonvegamount/$conversion_rate)).'</td>
//                     </tr>'; }
//                     $message .= '<tr style="line-height:30px;font-family:geogtq_regular;">
//                         <td style="width:70%;border-bottom:1px solid #FF5A5A;padding:2px 5px;"><b>Total amount due to you</b></td>
//                         <td style="width:30%;border-bottom:1px solid #FF5A5A;padding:2px 5px;">'.$currency_name.' <b>'.number_format(ceil($totalamountarray/$conversion_rate)).'</b></td>
//                     </tr></tbody>
//             </table>';
//             }
//             $message .= '<p style="margin:10px 0px;">For any queries please give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">You are receiving this email because you signed up for Authenticook. If you did not make this request, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
  
//   if($hostisdcode == 91) {
//     $authKey = "178491Afd8c7bhT59db20d0";

//     $senderId = "ATCOOK";

//     $route = "4";
    
//     $mobileNumber = $hostmobile;

//     $message = urlencode("Hey, ".$hostfname.", the total number of diners for ".$mealname." meal experience scheduled on ".date_format($newdate, 'dS, M')." at ".date('h:i A', strtotime($starttime))." are ".$formtext.". In case there are additional bookings from now till the meal date, we will call you personally. Call us on +918448449122 for any queries.\n\nTeam Authenticook");

//     $postData = array(
//       'authkey' => $authKey,
//       'mobiles' => $mobileNumber,
//       'message' => $message,
//       'sender' => $senderId,
//       'route' => $route,
//       'unicode' => 1
//     );

//     $url="https://smsp.myoperator.co/api/sendhttp.php";

//     $ch = curl_init();
//     curl_setopt_array($ch, array(
//       CURLOPT_URL => $url,
//       CURLOPT_RETURNTRANSFER => true,
//       CURLOPT_POST => true,
//       CURLOPT_POSTFIELDS => $postData
//     ));

//     curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
//     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

//     if(AN_SERVER == 'live_server') { $output = curl_exec($ch); }

//     curl_close($ch);
//   }
// }



// function modificationmailforhostadd($mealname, $cuisine, $newdate, $host_fname, $fname, $confirmationvouchercode, $city, $vegdinersmodify, $nonvegdinersmodify, $hostemail) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($hostemail);
//     $mail->addBCC("contact@authenticook.com");
    
//     $totaldiners = $vegdinersmodify + $nonvegdinersmodify;
    
//     if($totaldiners == 1) {
//         $seattext = "seat";
//     } else {
//         $seattext = "seats";
//     }
    
//     if(!empty($vegdinersmodify) && !empty($nonvegdinersmodify)) {
//         $additiontext = "Addition of ".$vegdinersmodify." Veg Diner(s) & ".$nonvegdinersmodify." Non-Veg Diner(s)";
//     } else if(!empty($vegdinersmodify) && empty($nonvegdinersmodify)) {
//         $additiontext = "Addition of ".$vegdinersmodify." Veg Diner(s)";
//     } else if(empty($vegdinersmodify) && !empty($nonvegdinersmodify)) {
//         $additiontext = "Addition of ".$nonvegdinersmodify." Non-Veg Diner(s)";
//     }
    
//     $mail->Subject = "Authenticook Meal Modification request for ".$totaldiners." ".$seattext." for ".$cuisinename." - ".$mealname." on ".date_format($newdate, "l dS F");
//     $message = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Hey '.$host_fname.',</p>
//             <p style="margin:10px 0px;">We have received a meal modification request for your '.$cuisinename." - ".$mealname.' on '.date_format($newdate, "l dS F").'</p>
//             <p style="margin:10px 0px;">The details are mentioned below</p>
//             <p style="margin:10px 0px;"><b>From: </b>'.$fname.'</p>
//             <p style="margin:10px 0px;"><b>Confirmation Code: </b>'.$confirmationvouchercode.'</p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b>'.$cuisinename." - ".$mealname.'</p>
//             <p style="margin:10px 0px;"><b>Host: </b>'.$host_fname.'</p>
//             <p style="margin:10px 0px;"><b>Action: </b>'.$additiontext.'</p>
//             <p style="margin:10px 0px;">You will receive a revised mail with the diner details 36 hours before the meal. In the meantime, you can check the booking details on your profile dashboard (<a href="'.$baseurl.'host-upcoming-meals/" style="color: #FF5A5A; text-decoration: none;">click here to view</a>)</p>
//             <p style="margin:10px 0px;">For any queries please give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you have any queries, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function modificationmailforhostremove($mealname, $cuisine, $newdate, $host_fname, $fname, $confirmationvouchercode, $city, $totalnewvegnonvegdinercount, $hostemail) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($hostemail);
//     $mail->addBCC("contact@authenticook.com");
    
//     if($totalnewvegnonvegdinercount == 1) {
//         $seattext = "seat";
//     } else {
//         $seattext = "seats";
//     }
    
//     $mail->Subject = "Authenticook Meal Modification request for ".$totalnewvegnonvegdinercount." ".$seattext." for ".$cuisinename." - ".$mealname." on ".date_format($newdate, "l dS F");
//     $message = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Hey '.$host_fname.',</p>
//             <p style="margin:10px 0px;">We have received a meal modification request for your '.$cuisinename." - ".$mealname.' on '.date_format($newdate, "l dS F").'</p>
//             <p style="margin:10px 0px;">The details are mentioned below</p>
//             <p style="margin:10px 0px;"><b>From: </b>'.$fname.'</p>
//             <p style="margin:10px 0px;"><b>Confirmation Code: </b>'.$confirmationvouchercode.'</p>
//             <p style="margin:10px 0px;"><b>City: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Meal: </b>'.$cuisinename." - ".$mealname.'</p>
//             <p style="margin:10px 0px;"><b>Host: </b>'.$host_fname.'</p>
//             <p style="margin:10px 0px;"><b>Action: </b>Cancellation of '.$totalnewvegnonvegdinercount.' Diner(s)</p>
//             <p style="margin:10px 0px;">You will receive a revised mail with the diner details 36 hours before the meal. In the meantime, you can check the booking details on your profile dashboard (<a href="'.$baseurl.'host-upcoming-meals/" style="color: #FF5A5A; text-decoration: none;">click here to view</a>)</p>
//             <p style="margin:10px 0px;">For any queries please give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a></p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//             <p style="margin-bottom: 0px;margin-top: 10px; padding: 0px 10px; font-size: 10px;">If you have any queries, please call us on <a href="tel:+918448449122" style="color: #fff; text-decoration: none;">+918448449122</a> or <a href="tel:+91 98194 97968" style="color: #fff; text-decoration: none;">+91 98194 97968</a> or write to us at <a href="mailto:contact@authenticook.com" style="color: #fff; text-decoration: none;">contact@authenticook.com</a></p>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function becomeahostnotifydiner($email, $user_fname, $mobilenumber) {
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress($email);
//     $mail->addBCC("contact@authenticook.com");
    
//     $mail->Subject = "Become a Host request received from you";
//     $message = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Dear '.$user_fname.',</p>
//             <p style="margin:10px 0px;">We have received a request from you to become a host. We will get in touch with you on the below contact details that we have of yours.</p>
//             <p style="margin:10px 0px;"><b>Email: </b><a href="mailto:'.$email.'" style="color: #FF5A5A; text-decoration: none;">'.$email.'</a></p>
//             <p style="margin:10px 0px;"><b>Mobile number: </b>'.$mobilenumber.'</p>
//             <p style="margin:10px 0px;">If either or both of these details are incorrect, we would request you to kindly give us a shout at <a href="mailto:contact@authenticook.com" style="color: #FF5A5A; text-decoration: none;">contact@authenticook.com</a> or call us on <a href="tel:+918448449122" style="color: #FF5A5A; text-decoration: none;">+918448449122</a></p>
//             <p>Regards</p>
//             <p>Team Authenticook</p>
//             <p>Eat. Enjoy. Experience.</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

// function becomeahostnotifyadmin($email, $dinerfullname, $mobilenumber, $city, $userid, $gender, $arealocality, $transportation, $hometype, $place_to_host_the_diners, $cuisine_specialization, $specialization_description, $pictures_attached) {
//   global $conn;
//   $target_dir = "images/host_home_pictures/";
  
//     $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress("contact@authenticook.com");
    
//     $mail->Subject = "Request from Diner to Become a Host";
  
//   $gethomepictures = $conn->query("SELECT image_name FROM tbl_host_details_gallery WHERE user_id = $userid");
//   while($gethomepicturesrow = $gethomepictures->fetch_array()) {
//     $imagename = $gethomepicturesrow['image_name'];
    
//     $mail->addAttachment($target_dir.$imagename);
//   }
  
//     $message = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Dear \'Best team in the world\',</p>
//             <p style="margin:10px 0px;">We have received a request from a diner to become a host. You are required to get in touch with them. Below are his / her details.</p>
//             <p style="margin:10px 0px;"><b>From: </b><a href="'.$baseurl.'authenticook-panel/editdiner.php?id='.$userid.'">'.$dinerfullname.'</a></p>
//             <p style="margin:10px 0px;"><b>Diner\'s Email: </b>'.$email.'</p>
//             <p style="margin:10px 0px;"><b>Diner\'s mobile number: </b>'.$mobilenumber.'</p>
//             <p style="margin:10px 0px;"><b>City of residence: </b>'.$city.'</p>
//             <p style="margin:10px 0px;"><b>Gender: </b>'.$gender.'</p>
//       <p style="margin:10px 0px;"><b>Area/Locality: </b>'.$arealocality.'</p>
//       <p style="margin:10px 0px;"><b>Transport availability: </b>'.$transportation.'</p>
//       <p style="margin:10px 0px;"><b>Home Type: </b>'.$hometype.'</p>
//       <p style="margin:10px 0px;"><b>Place to Host the Diners: </b>'.$place_to_host_the_diners.'</p>
//       <p style="margin:10px 0px;"><b>Cuisine Specialization: </b>'.$cuisine_specialization.'</p>
//       <p style="margin:10px 0px;"><b>Why this cuisine: </b>'.$specialization_description.'</p>
//       <p style="margin:10px 0px;"><b>Pictures: </b>'.$pictures_attached.'</p>
//             <p style="margin:10px 0px;"><b>Date of request: </b>'.date('dS M, Y').'</p>
//             <p style="margin:10px 0px;">The following actions are needed from your side</p>
//             <ul>
//                 <li>You need to reach out to the diner via a phone call and get the empanelment process underway</li>
//             </ul>
//             <p>Thank You,</p>
//             <p>Jarvis</p>
//             <p>Team Authenticook</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
  
//   $gethomepictures = $conn->query("SELECT image_name FROM tbl_host_details_gallery WHERE user_id = $userid");
//   while($gethomepicturesrow = $gethomepictures->fetch_array()) {
//     $imagename = $gethomepicturesrow['image_name'];
    
//     unlink($target_dir.$imagename);
//   }
// }

// function approvalformealpublishing($mealname, $hostname, $newdate, $mealtype, $starttime, $endtime, $mindiners, $maxdiners, $leadtime, $mealtypevegnonveg, $vegprice, $nonvegprice, $urlslug, $meallistingid, $mealid) {
//   $baseurl = "https://www.authenticook.com/";
//     $mail = new PHPMailer();
    
//     $mail->IsSMTP();
//     $mail->SMTPAuth = true;
//     $mail->SMTPSecure = "tls";
//     $mail->Host = "smtp.gmail.com";
//     $mail->Port = 587;
//     $mail->isHTML(true);
//     $mail->Username = "contact@authenticook.com";
//     $mail->Password = "asap@0510";
    
//     $mail->From = "contact@authenticook.com";
//     $mail->FromName = "Authenticook";
//     $mail->addAddress("contact@authenticook.com");
    
//     $mail->Subject = "Publish meal request for ".$mealname." by home-chef ".$hostname." for ".date('dS F, Y', strtotime($newdate))." - ".$mealtype;
//     $message = '<html>
//     <body style="margin:0;padding:0;width:100%;margin:auto;">
//         <div style="border:3px solid #FF5A5A;text-align:center;height: 75px;padding-top: 20px;padding-bottom: 15px;box-sizing: border-box;">
//             <a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/logo.png"></a>
//         </div>
//         <div style="padding:15px 25px;border:1px solid #FF5A5A;border-top:0px;">
//             <p style="margin:10px 0px;">Dear \'Best team in the world\',</p>
//             <p style="margin:10px 0px;">We have received a request to publish a meal with the following details</p>
//       <p style="margin:10px 0px;">Name of the host: '.$hostname.'</p>
//       <p style="margin:10px 0px;">Meal Name: <a href="'.$baseurl.'meal/'.$urlslug.'/'.$mealid.'/'.$meallistingid.'/">'.$mealname.'</a></p>
//       <p style="margin:10px 0px;">Date: '.date('dS F, Y', strtotime($newdate)).'</p>
//       <p style="margin:10px 0px;">Type: '.$mealtype.'</p>
//       <p style="margin:10px 0px;">Start time: '.date('h:i A', strtotime($starttime)).'</p>
//       <p style="margin:10px 0px;">End time: '.date('h:i A', strtotime($endtime)).'</p>
//       <p style="margin:10px 0px;">Minimum Number of diners: '.$mindiners.'</p>
//       <p style="margin:10px 0px;">Maximum Number of diners: '.$maxdiners.'</p>
//       <p style="margin:10px 0px;">Lead time: '.$leadtime.' Hours</p>
//       <p style="margin:10px 0px;">Meal Type: '.$mealtypevegnonveg.'</p>
//       <p style="margin:10px 0px;">Host Pricing: Veg: '.$vegprice.'</p>
//       <p style="margin:10px 0px;">Host Pricing: Non-Veg: '.$nonvegprice.'</p>
//             <p style="margin:10px 0px;">The following actions are needed from your side</p>
//             <ul>
//                 <li>You need to reach out to '.$hostname.' and confirm /deny the booking</li>
//             </ul>
//             <p>Thank You,</p>
//             <p>Jarvis</p>
//             <p>Team Authenticook</p>
//         </div>
//         <div style="background-color:#FF5A5A;text-align:center;height: auto;padding: 10px 0;box-sizing: border-box;color:#fff;">
//             <a href="https://www.facebook.com/authenticook"><img src="'.$baseurl.'email-images/new_mfb.png" style="margin:0 8px; width: 25px;"></a><a href="https://instagram.com/authenticook"><img src="'.$baseurl.'email-images/new_minsta.png" style="margin:0 8px; width: 25px;"></a><a href="https://twitter.com/authenticook"><img src="'.$baseurl.'email-images/new_mtwit.png" style="margin:0 8px; width: 25px;"></a><a href="'.$baseurl.'"><img src="'.$baseurl.'email-images/new_globe.png" style="margin:0 8px; width: 25px;"></a>
//         </div>
//     </body>
// </html>';
    
//     $mail->Body = $message;
//     if(AN_SERVER == 'live_server') { $mail->send(); }
// }

