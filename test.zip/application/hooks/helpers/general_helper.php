<?php

		function admin() {
		    $CI = &get_instance();
		    $user_id = @$CI->session->userdata['logged_in']['user_id'];
		    if (($user_id != "")) {
		        return true;
		    } else {
		        // die;
		        redirect('admin/login/logout', 'refresh');
		    }
		}

function file_upload_function($path,$filename){
  //Image Config 
      $config['upload_path'] = $path;
      $config['allowed_types'] = 'gif|jpg|png|jpeg';
      // $config['max_size'] = 1000;
      // $config['max_width'] = 1920;
      // $config['max_height'] = 1073;
      $CI = &get_instance();
      $CI->load->library('upload', $config);
     if (!$CI->upload->do_upload($filename)) {
          $error = array('error' => $CI->upload->display_errors());
          // echo $error['error'];
         $CI->session->set_flashdata('message', $error['error']);

         print_r($error['error']);
         die;
         $config['upload_path'] ="";
     } else {
        array('upload_data' => $CI->upload->data());
        $upload_data = $CI->upload->data();
        $result = $upload_data['file_name'];
        return $result;
        exit(); 
     }
}
    





function post_curl($url,$post_data=FALSE) {
    // die('sadasdsad');
  // $head = array("Token:$this->token");
  // print_r($post_data);die;
  
   $cSession1 = curl_init();
   curl_setopt($cSession1,CURLOPT_URL,$url);
   curl_setopt($cSession1, CURLOPT_CUSTOMREQUEST, "POST");
   curl_setopt($cSession1,CURLOPT_RETURNTRANSFER,true);
   // curl_setopt($cSession1, CURLOPT_HTTPHEADER, array('Token:'.$this->token) );
   curl_setopt($cSession1, CURLOPT_POSTFIELDS, $post_data);
   $result=curl_exec($cSession1);
   curl_close($cSession1);
   // echo "<pre>";
   // print_r($result);
   // die;
   return $result;
}

function get_curl($url){
  //  Initiate curl
  $ch = curl_init();
  // Disable SSL verification
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  // Will return the response, if false it print the response
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  // Set the url
  curl_setopt($ch, CURLOPT_URL,$url);
  // Execute
  $result=curl_exec($ch);
  return $result;
  // Closing
  // curl_close($ch);

  // // Will dump a beauty json :3
  // var_dump(json_decode($result, true));
}

