<div class="row">
        <div class="col-sm-6">
                <h3>Ans 1 Create Update & Softdelete (REST API)</h3>
               

<p>To run this use postman

<ol type="a">
<li>URL : <?php echo base_url(); ?>home/add_data<br>
Parameter : hostname,loopback,sapid,macaddress</li>
<li>URL : <?php echo base_url(); ?>home/update_data<br>
Parameter : id and requred feilds you want to update
</li>
<li>URL : <?php echo base_url(); ?>home/get_data<br>
Parameter : sapid
</li>
<li>URL : <?php echo base_url(); ?>home/get_iprange_data<br>
Parameter : id
</li>
<li>URL : <?php echo base_url(); ?>home/delete_data<br>
Parameter : id
</li>
</ol>
