<div style="text-align: center;color: red">
    Hi, I have created both curd operation MVC and AJAX please click the link<br>
<a class="" href="<?php echo base_url('home') ?>">AJAX CURD</a> | <a href="<?php echo base_url('home/mvc_curd') ?>">MVC CURD</a>
</div>
<br><br>

<div class="col-sm-12">
    <div class="row">
        

        <div class="col-sm-12">
            <h3>Ans 1/2: Create Update & Softdelete (AJAX)</h3>

                <form method="post">
                <table class="table" border="0">
                <tr>
                    <td style="width: 10%">Sapid</td>
                    <td class="col-lg-11">
                        <input type="hidden" id="routerid" class="form-control" name="routerid" >
                        <input required type="text" id="sapid" class="form-control" name="sapid">
                    </td>
                </tr>
                <tr>
                    <td>Hostname</td>
                    <td><input required type="text" id="hostname" class="form-control"  name="hostname"></td>
                </tr>
                <tr>
                    <td>Loopback</td>
                    <td><input required type="text" id="loopback" class="form-control" name="loopback"></td>
                </tr>
                <tr>
                    <td>Macaddress</td>
                    <td><input required type="text" id="macaddress" class="form-control" name="macaddress"></td>
                </tr>

                <tr><td></td>
                    <td colspan="1"><input class="btn btn-primary" id="btn_save" value="Submit" type="button" name="action">
                        <input class="btn btn-primary" id="btn_update" value="Update" type="button" name="action"></td>
                </tr>
                </table>
                </form>
        </div>
    </div>

    <div class="row">
       
        <div class="col-sm-12">
            <!-- View data -->
            <h3>View details (Ajax)</h3>

            <table  class="table" id="show_search_results">
                <thead>
            <tr>
            <th>Sapid</th>
            <th>Hostname</th>
            <th>Loopback</th>
            <th>Mac Address</th>
            <th>Status</th>
            <th>Action</th>
            </tr>
        </thead>
            <tbody id="show_data">
                     
                </tbody>
            </table>

        </div>
    </div>

</div>



<h2>Ans 3:</h2>
    <p>First goto project folder using command I have created a function in home controller to run that function kindly fire below command it will insert data in above table. I have set limit 50.</p>
    <p>php index.php home genrate_dummy_data</p>

