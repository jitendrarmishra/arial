<script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>


<script type="text/javascript">
    $(document).ready(function(){
		$('#btn_update').hide();
        show_product(); //call function show all data
        function show_product(){
            $.ajax({
                type  : 'ajax',
                url   : '<?php echo site_url('home/get_all_data')?>',
                async : true,
                dataType : 'json',
                success : function(data){
                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                        html += '<tr>'+
                                '<td>'+data[i].sapid+'</td>'+
                                '<td>'+data[i].hostname+'</td>'+
                                '<td>'+data[i].loopback+'</td>'+
                                '<td>'+data[i].macaddress+'</td>'+
                                '<td style="text-align:right;">'+
                                    '<a href="javascript:void(0);" class="btn btn-info btn-sm item_edit" data-id="'+data[i].id+'" data-sapid="'+data[i].sapid+'" data-hostname="'+data[i].hostname+'" data-loopback="'+data[i].loopback+'" data-macaddress="'+data[i].macaddress+'"">Edit</a>'+' '+
                                    '<a href="javascript:void(0);" class="btn btn-danger btn-sm item_delete" data-product_code="'+data[i].id+'">Delete</a>'+
                                '</td>'+
                                '</tr>';
                    }
                    $('#show_data').html(html);
                }
 
            });
        }
 
        //Save product
        $('#btn_save').on('click',function(){
            var sapid = $('#sapid').val();
            var hostname = $('#hostname').val();
            var loopback = $('#loopback').val();
            var macaddress = $('#macaddress').val();
			if(sapid == "")
			{
				alert('Sapid is required!')
				$('#sapid').focus();
				return false;
			}
			if(hostname == "")
			{
				alert('Hostname is required!')
				$('#hostname').focus();
				return false;
			}
			if(loopback == "")
			{
				alert('Loopback is required!')
				$('#loopback').focus();
				return false;
			}
			if(macaddress == "")
			{
				alert('Macaddress is required!')
				$('#macaddress').focus();
				return false;
			}
// console.log(sapid);
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('home/add')?>",
                dataType : "JSON",
                data : {sapid:sapid,hostname:hostname,loopback:loopback,macaddress:macaddress},
                success: function(data){
					$('#sapid').val('');
		            $('#hostname').val('');
		            $('#loopback').val('');
		            $('#macaddress').val('');
                    show_product();
                }
            });
            return false;
        });
 
        //get data for update record
        $('#show_data').on('click','.item_edit',function(){
            var sapid = $(this).data('sapid');
            var hostname = $(this).data('hostname');
            var loopback = $(this).data('loopback');
            var macaddress = $(this).data('macaddress');
            var id = $(this).data('id');
			
			
			$('#btn_save').hide();
			$('#btn_update').show();
            $('[name="macaddress"]').val(macaddress);
            $('[name="loopback"]').val(loopback);
            $('[name="hostname"]').val(hostname);
            $('[name="sapid"]').val(sapid);
            $('[name="routerid"]').val(id);
        });

        //update record to database
         $('#btn_update').on('click',function(){
			var sapid = $('#sapid').val();
            var hostname = $('#hostname').val();
            var loopback = $('#loopback').val();
            var macaddress = $('#macaddress').val();
            var routerid = $('#routerid').val();
			if(sapid == "")
			{
				alert('Sapid is required!')
				$('#sapid').focus();
				return false;
			}
			if(hostname == "")
			{
				alert('Hostname is required!')
				$('#hostname').focus();
				return false;
			}
			if(loopback == "")
			{
				alert('Loopback is required!')
				$('#loopback').focus();
				return false;
			}
			if(macaddress == "")
			{
				alert('Macaddress is required!')
				$('#macaddress').focus();
				return false;
			}

			$('#btn_save').show();
			$('#btn_update').hide();
            
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('home/update')?>",
                dataType : "JSON",
                data : {id:routerid , sapid:sapid, hostname:hostname, loopback:loopback, macaddress:macaddress},
                success: function(data){
					$('#sapid').val('');
		            $('#hostname').val('');
		            $('#loopback').val('');
		            $('#macaddress').val('');
                    show_product();
                }
            });
            return false;
        });
 
        //delete record to database
        $('#show_data').on('click','.item_delete',function(){
            var item_code = $(this).data('product_code');
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('home/delete')?>",
                dataType : "JSON",
                data : {id:item_code},
                success: function(data){
                    show_product();
                }
            });
            return false;
        });
    });
 
</script>

<script>
	$( document ).ready(function() {
    console.log( "ready!" );
});
	
      $("#ajax_search").keyup(function () {
        $.ajax({
	      type: "POST",
	      url: "<?php echo base_url() ?>home/search",
	      data: ({search: $("#ajax_search").val()}),
	      success: function(data) {
	       // $("#show_search_results").show();  
	       $("#show_search_results").html(data); 
	      }      
	    }); 
   });
           

</script>
</body>
</html>
