<h2>Ans1</h2>
<ol type="a">
<li> telnet server ip</li>
<li> ssh root@yourserver.com</li>
<li> df -h or lsblk</li>
<li> ls -lai </li>
<li> ls -l</li>
<li> cp -b /home/ariel/test/abc.php /media/sda3/SkyDrive
</li>
</ol>

<h2>Ans2</h2>
<p>sudo apt-get install zip</p>
<p>zip -r {filename.zip} {foldername}</p>


<h3>Ans3:</h3>
<p> /etc/init.d/apache2 restart</p>
<pre>#!/bin/sh
check=`cat /proc/loadavg | sed 's/\./ /' | awk '{print $1}'`
if [ $check -gt 10 ] //10 is load average on 5 minutes
then
/etc/init.d/httpd restart
fi
</pre>


<h3>Ans4</h3>

<p>Linux Top command is a performance monitoring program which is used frequently by many system administrators to monitor server performance</p>
<p> It display CPU usage, Memory usage, Swap Memory, Cache Size, Buffer Size, Process PID, User, Commands and much more. </p>

<ol type="a">
    <li>top command</li>
<li>htop module is best way to monitor server, to install user <b>sudo apt-get install htop</b><br>To start just type <b>htop</b> and enter</li>
<li></li>
    </ol>



<h3>Ans5</h3>
<p><b>Create view</b></p>
<p>CREATE VIEW bigSalesOrder AS
    SELECT orderNumber, ROUND(total,2) as total FROM salePerOrder
    WHERE total > 60000;</p>
<p><b>Select view</b></p>
    <p>SELECT orderNumber,total FROM bigSalesOrder;</p>

<h3>Ans6</h3>
<p>INSERT INTO `router` (`id`, `hostname`, `loopback`, `macaddress`, `sapid`, `status`, `add_time`) VALUES (NULL, '192.168.0.1', '192.168.0.1', 'ABC:192.168.0.1', 'ABCD:192.168.0.1', 'active', CURRENT_TIMESTAMP);</p>
