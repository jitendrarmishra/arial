<?php 
   if($alldata)
   {?>
         <tr>
            <th>Sapid</th>
            <th>Hostname</th>
            <th>Loopback</th>
            <th>Macaddress</th>
            <th>Status</th>
            <th>Action</th>
         </tr>

   <?php foreach ($alldata as $value) { ?>
         <tr id="show_search_results">
            <td><?php echo $value->sapid  ?></td>
            <td><?php echo $value->hostname ?></td>
            <td><?php echo $value->loopback ?></td>
            <td><?php echo $value->macaddress ?></td>
            <td><?php echo $value->status ?></td>
            <td><a href="<?php echo base_url() ?>home/index/<?php echo $value->id ?>">Edit</a> | <a href="<?php echo base_url() ?>home/delete/<?php echo $value->id ?>">Delete</a></td>
         </tr>
<?php
      }
   }
   else
   {?>
      <tr>
            <th>Sapid</th>
            <th>Hostname</th>
            <th>Loopback</th>
            <th>Macaddress</th>
            <th>Status</th>
            <th>Action</th>
         </tr>

       <tr id="show_search_results">
            <th colspan="6" class="text-center">Data not found!</th>
         </tr>

   <?php
   }
?>