<meta>
  <title>PHP Test - AERIAL TELECOM SOLUTIONS PVT. LIMITED</title>
  <!-- Tell the browser to be responsive to screen width -->
  
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/bootstrap/css/bootstrap.min.css">
</head>
<body>
	
	<a href="<?php echo site_url('home') ?>" class="btn btn-info">Exercise 1</a>
	<a href="<?php echo site_url('home/exercise2') ?>" class="btn btn-info">Exercise 2</a>
	<a href="<?php echo site_url('home/exercise3') ?>" class="btn btn-info">Exercise 3</a>
	<div style="margin-bottom:30px "></div>