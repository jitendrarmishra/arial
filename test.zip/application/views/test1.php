<div style="text-align: center;color: red">
    Hi, I have created both curd operation MVC and AJAX please click the link<br>
<a class="" href="<?php echo base_url('home') ?>">AJAX CURD</a> | <a href="<?php echo base_url('home/mvc_curd') ?>">MVC CURD</a>
</div>
<br><br>

<?php
    if(!empty($edit))
    {
    $id = $edit->id;
    $sapid = $edit->sapid;
    $hostname = $edit->hostname;
    $loopback = $edit->loopback;
    $macaddress = $edit->macaddress;
    $action = site_url('home/update_mvc');
    }
    else
    {
    $id = "";
    $sapid = "";
    $hostname = "";
    $loopback = "";
    $macaddress = "";
    $action = site_url('home/add_mvc');
    }
?>
<div class="col-sm-12">
                <h3>Ans 1/2: Create Update & Softdelete (MVC)</h3>
                <form action="<?php echo $action ?>" method="post">
                <table class="table" border="0">
                <tr>
                    <td style="width: 10%">Sapid</td>
                    <td class="col-lg-11">
                        <input type="hidden" class="form-control" name="id" value="<?php echo $id ?>">
                        <input required type="text" class="form-control" name="sapid" value="<?php echo $sapid ?>">
                    </td>
                </tr>
                <tr>
                    <td>Hostname</td>
                    <td><input required type="text" class="form-control" value="<?php echo $hostname ?>" name="hostname"></td>
                </tr>
                <tr>
                    <td>Loopback</td>
                    <td><input required type="text" class="form-control" name="loopback" value="<?php echo $loopback ?>"></td>
                </tr>
                <tr>
                    <td>Macaddress</td>
                    <td><input required type="text" class="form-control" name="macaddress" value="<?php echo $macaddress ?>"></td>
                </tr>

                <tr><td></td>
                    <td colspan="1"><input class="btn btn-primary" type="submit" name="action"></td>
                </tr>

                </table>
                </form>

                 <div class="col-sm-12">
            <h3>View details (MVC)</h3>

            
            <table  class="table" id="show_search_results_mvc">
            <tr>
            <th>Sapid</th>
            <th>Hostname</th>
            <th>Loopback</th>
            <th>Mac Address</th>
            <th>Status</th>
            <th>Action</th>
            </tr>
            <?php 
            if(!empty($alldata))
            {
            foreach ($alldata as $value) { ?>
            <tr>
            <td><?php echo $value->sapid  ?></td>
            <td><?php echo $value->hostname ?></td>
            <td><?php echo $value->loopback ?></td>
            <td><?php echo $value->macaddress ?></td>
            <td><?php echo $value->status ?></td>
            <td><a class="btn btn-primary" href="<?php echo base_url() ?>home/mvc_curd/<?php echo $value->id ?>">Edit</a> | <a class="btn btn-danger" href="<?php echo base_url() ?>home/delete_mvc/<?php echo $value->id ?>">Delete</a></td>
            </tr>
            <?php
            }
            }
            else
            {?>
            <tr id="show_search_results">
            <th colspan="6" class="text-center">Data not found!</th>
            </tr>
            <?php
            }
            ?>
            </table>

        </div>

        </div> 


<h2>Ans 3:</h2>
    <p>First goto project folder using command I have created a function in home controller to run that function kindly fire below command it will insert data in above table. I have set limit 50.</p>
    <p>php index.php home genrate_dummy_data</p>
