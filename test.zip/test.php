<?php
//step1
// $cSession = curl_init(); 
//  $url = "http://localhost/authenticook/user/get_users/";
// //step2
// curl_setopt($cSession,CURLOPT_URL,$url);
// curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
// curl_setopt($cSession,CURLOPT_HEADER, false); 
// //step3
// $result=curl_exec($cSession);
// //step4
// curl_close($cSession);
// //step5
//   print_r($result);
?>

<?php
//step1
$cSession1 = curl_init(); 
 $url = "http://localhost/authenticook/user/get_userById/";
//step2
 $data = json_encode(array('id' => '1'));
curl_setopt($cSession1,CURLOPT_URL,$url);
curl_setopt($cSession1, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($cSession1,CURLOPT_RETURNTRANSFER,true);
curl_setopt($cSession1,CURLOPT_HEADER, false); 
curl_setopt($cSession1, CURLOPT_POSTFIELDS, $data);
//step3
$result=curl_exec($cSession1);
//step4
curl_close($cSession1);
//step5
  print_r($result);
?>